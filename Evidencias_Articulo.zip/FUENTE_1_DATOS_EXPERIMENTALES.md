# FUENTE 1: DATOS EXPERIMENTALES CRUDOS

## Descripción
Resultados matemáticos obtenidos directamente del experimento ejecutado con el script `latencia_test.js`. Estos son los datos numéricos exactos que deben usarse en la sección de Resultados del artículo. Los datos provienen de archivos CSV (`resultados_latencia_http.csv`, `resultados_latencia_ws.csv`) con 4,002 filas totales por protocolo.

> **Nota sobre el framing correcto de la emulación de red:** La inyección de condiciones adversas (50ms lag + 1% packet loss) NO se presentará en el artículo como simulación de red 4G, sino como un **Análisis de Caso Extremo (Worst-Case Scenario)**. PianoFlows opera sobre WiFi/LAN, pero las redes domésticas reales presentan interferencias, saturación de router y pérdida de paquetes similares a los emulados. El objetivo es exponer las diferencias de comportamiento de los protocolos que en una LAN ideal permanecerían ocultas, estableciendo un escenario de estrés reproducible y controlado.

---

## Configuración del Experimento
- **Protocolo A (Control):** HTTP REST — `POST /api/test/note`
- **Protocolo B (Propuesto):** WebSocket con Socket.io — evento `test_latencia_ws`
- **Clientes concurrentes simulados:** 4 (emulando una sala completa del "Módulo Sala de Conciertos")
- **Iteraciones por cliente:** 1,000
- **Total de iteraciones por protocolo:** 4,000
- **Fase de calentamiento (Warm-up) descartada:** primeras 100 iteraciones (10%) por cliente
- **Muestras válidas en estado estable (STEADY) analizadas:** 3,600 por protocolo
- **Frecuencia de notas por cliente:** 25 notas/seg → 100 notas/seg en total al servidor
- **Justificación del tamaño de muestra:** Bozakov y Susitaival (2013) utilizaron ráfagas continuas para evaluar WebSocket bajo carga sostenida

---

## Emulación de Red (Worst-Case Scenario Analysis)
- **Herramienta:** Clumsy (Windows)
- **Filtro aplicado:** `tcp.DstPort == 3000 or tcp.SrcPort == 3000`
- **Latencia inyectada (Lag):** 50 ms simétrico (inbound + outbound)
- **Pérdida de paquetes (Drop/Packet Loss):** 1.0%
- **Propósito:** Establecer un escenario de estrés adverso controlado y reproducible. Las redes WiFi domésticas reales (el entorno de uso esperado de PianoFlows) presentan interferencias, saturación del router y pérdida de paquetes intermitente similares a los parámetros emulados. El objetivo es revelar diferencias de resiliencia entre protocolos que en una LAN ideal permanecerían latentes.

---

## Resultados de Latencia (RTT en milisegundos)
> Los valores corresponden exclusivamente a la fase **STEADY** (N=3,600 por protocolo, descartando las primeras 100 iteraciones de warm-up por cliente).

| Métrica                   | HTTP (REST)  | WebSocket (Socket.io) |
|---------------------------|-------------:|----------------------:|
| **Media (x̄)**            | 142.13 ms    | 176.35 ms             |
| **Varianza (s²)**         | 3,590.65     | 3,975.87              |
| **Desv. Estándar (s)**    | 59.92 ms     | 63.05 ms              |
| **Pico Máximo (Max RTT)** | **1,318 ms** | **580 ms**            |
| **Mínimo (Min RTT)**      | 104 ms       | 104 ms                |
| **Muestras STEADY (N)**   | 3,600        | 3,600                 |

---

## Resultados de Consumo de Hardware del Servidor (Node.js)

| Métrica                     | HTTP (REST) | WebSocket (Socket.io) |
|-----------------------------|------------:|----------------------:|
| **CPU Load Average (OS)**   | 1.607       | 1.612                 |
| **RAM Heap usada (V8)**     | 21.76 MB    | 22.29 MB              |

*Nota: El consumo de hardware fue prácticamente idéntico en ambos protocolos, lo que confirma que el cuello de botella observado fue exclusivamente de red/protocolo y no de capacidad de cómputo.*

---

## Prueba de Significancia Estadística (Prueba T de Welch)
Se aplicó la Prueba T de Welch (para muestras con varianzas desiguales) dado que s²_HTTP (3,590.65) ≠ s²_WS (3,975.87). Ver desarrollo matemático completo en **FUENTE_6_MATEMATICA_ESTADISTICA.md**.

| Parámetro estadístico        | Valor       |
|------------------------------|------------:|
| **Estadístico T**            | 23.5997     |
| **Grados de libertad (df)**  | 7,179       |
| **Valor p (p-value)**        | < 0.0001    |
| **Nivel de significancia α** | 0.05        |
| **Decisión**                 | Se rechaza H₀ |

**Hipótesis:**
- H₀ (Nula): No existe diferencia estadísticamente significativa entre la latencia media de HTTP REST y WebSocket bajo condiciones de red adversas emuladas.
- H₁ (Alternativa): WebSocket presenta una latencia media estadísticamente diferente a la de HTTP REST bajo condiciones de red adversas emuladas.

**Conclusión:** Con T=23.5997 y p<0.0001, se rechaza H₀. La diferencia observada entre protocolos no es producto de variaciones aleatorias de red. La diferencia en los picos máximos (580ms vs 1,318ms) representa el hallazgo de mayor impacto práctico.
