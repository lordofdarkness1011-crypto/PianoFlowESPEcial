# FUENTE 5: ESTRUCTURA DEL ARTÍCULO Y DATOS POR SECCIÓN

## Descripción
Hoja de ruta con qué información va en cada sección del artículo Springer. Úsala como índice cruzado con los demás archivos FUENTE.

---

## Título Propuesto
*Evaluación de latencia y resiliencia en la transmisión de eventos MIDI en tiempo real: WebSockets frente a HTTP REST en un motor musical web distribuido*

---

## Resumen (Abstract) — **150 a 250 palabras** (rúbrica del profesor)
> ⚠️ La plantilla Springer dice 70-150 palabras, pero las instrucciones del profesor indican explícitamente 150-250. Prevalece la rúbrica del profesor.

**Contenido obligatorio:**
- El problema: la sincronización musical requiere latencias Jitter < 50ms (citar [7] Claypool 2014)
- El caso de estudio: PianoFlows (motor musical web multijugador, Node.js + Socket.io)
- Metodología en una oración: prueba de estrés concurrente (4 clientes, 100 eventos/seg) bajo condiciones WiFi adversas controladas (50ms lag + 1% packet loss, N=3,600 muestras)
- Resultado principal: WebSocket redujo los picos de latencia (Lag Spikes) en un 56% frente a HTTP (580 ms vs 1,318 ms)
- Prueba estadística: diferencia estadísticamente significativa (T=23.5997, df=7,179, p<0.0001)
- Conclusión: WebSocket es el único protocolo viable para garantizar Jitter acotado en motores musicales distribuidos
- Al final del resumen incluir entre 4 y 6 palabras clave con inicial en mayúscula (excepto artículos, preposiciones y conjunciones):
  `WebSocket, HTTP REST, Latencia, Jitter, Tiempo Real, Node.js`

> **Formato correcto de palabras clave según PrototipoSpringer.txt línea 7:** inicial en mayúscula excepto artículos/preposiciones.

---

> **Nota de entrega del PDF (PrototipoSpringer.txt línea 24):** El archivo PDF debe entregarse **sin númerar las páginas**.

---

## 1. Introducción
**7 elementos obligatorios según la rúbrica (todos deben estar presentes):**
1. **Contexto del problema:** El auge de los juegos musicales y educativos en la nube como PianoFlows. La sincronia musical es un caso extremo de tiempo real.
2. **Importancia técnica o práctica:** La desincronización de audio en un juego de ritmo destruye la experiencia del usuario de forma inaceptable, con umbrales menores a los de videoconferencia o streaming de video.
3. **Limitaciones de soluciones existentes:** El paradigma REST/HTTP, diseñado para interacciones transaccionales, no fue concebido para flujos de alta frecuencia. Las características de overhead de cabecera y handshake por petición lo hacen inadecuado para sincronización musical en tiempo real.
4. **Pregunta de investigación:** *¿Cómo afecta el protocolo de transmisión de red (HTTP REST vs WebSocket) a la latencia y la variabilidad (Jitter) de eventos MIDI en una aplicación musical web distribuida bajo condiciones de red adversas controladas?*
5. **Objetivo del estudio:** Evaluar y comparar cuantitativamente el comportamiento de los protocolos HTTP REST y WebSocket (Socket.io) bajo una carga de alta frecuencia de eventos MIDI en el Módulo Sala de Conciertos de PianoFlows, midiendo latencia media, picos máximos (Jitter) y consumo de recursos del servidor, bajo condiciones de red adversas emuladas.
6. **Aporte principal del artículo:** Demostrar empíricamente que, bajo condiciones de red adversas realistas (1% packet loss), WebSocket presenta picos de latencia (580 ms) un 56% menores que HTTP REST (1,318 ms), con diferencia estadísticamente significativa (T=21.75, p<0.0001), estableciendo que la persistencia de conexión es el único mecanismo viable para acotar el Jitter en motores musicales web.
7. **Organización del manuscrito:** El último párrafo de la introducción DEBE decir explícitamente: *"El presente artículo se organiza de la siguiente manera: la Sección 2 revisa los trabajos relacionados; la Sección 3 describe la arquitectura del sistema PianoFlows; la Sección 4 detalla la metodología experimental; la Sección 5 presenta los resultados; la Sección 6 discute los hallazgos y, finalmente, la Sección 7 expone las conclusiones y las líneas de trabajo futuro."*

> **Importante:** El PENULTIMO párrafo de la introducción debe indicar explícitamente cuál es la contribución: *"La principal contribución de este trabajo es la evaluación empírica del impacto de la elección de protocolo de red sobre el Jitter en la transmisión de eventos MIDI en tiempo real, demostrando que la latencia máxima (no la media) es la métrica crítica para la experiencia de usuario en aplicaciones musicales distribuidas."*

---

## 2. Trabajos Relacionados
**Cada fuente debe relacionarse con una diferencia concreta frente a este trabajo (no solo definiciones):**

| Referencia | Lo que estudia | Diferencia con este trabajo |
|---|---|---|
| Pimentel 2012 [5] | WebSocket vs HTTP Polling en visualización de datos | Evaluaron mensajeria general; este trabajo evalúa carga MIDI de alta frecuencia con 4 clientes concurrentes |
| Bozakov 2013 [6] | Evaluación de rendimiento de WebSocket en tiempo real | No aplican emulación de pérdida de paquetes; este trabajo sí introduce 1% packet loss |
| Fielding 2000 [3] | Define la arquitectura REST | Es la base teórica del Escenario A evaluado |
| Loreto 2011 [2] | Problemas del HTTP Polling | Documenta la problemática que motiva usar WebSocket |
| Claypool 2014 [7] | Latencia en Cloud Gaming | Evalún juegos generales; este trabajo se enfoca en sincronización musical (más estricta) |
| Huang 2013 [8] | Plataforma de Cloud Gaming abierta | Infraestructura de streaming; este trabajo evalúa protocolos de mensajería de eventos |
| Wang 2012 [9] | Calidad de red para Cloud Gaming | Perspectiva de operador de red; este trabajo evalúa desde la aplicación |
| Murley 2021 [10] | Adopción de WebSocket en la web | Estudio de adopción; este trabajo evalúa rendimiento bajo carga adversa |
| Soares 2023 [11] | Modelo QoE para Cloud Gaming con ML | Usan ML para predecir QoE; este trabajo mide directamente con pruebas de carga |

**Oración de diferenciación para incluir al final de la sección:**
*"A diferencia de los trabajos previos, que evaluaron WebSocket bajo cargas de mensajería general o entornos de streaming de video, el presente estudio aplica una carga específica de alta frecuencia de eventos MIDI (100 eventos/segundo con 4 clientes concurrentes), incorpora emulación de pérdida de paquetes para reproducir condiciones de red adversas realistas, e identifica la latencia máxima (Jitter) como la métrica crítica para la sincronización musical, frente al promedio de RTT usado en estudios previos."*

---

## 3. Arquitectura de la Solución (Caso de Estudio: PianoFlows)
**Contenido que debe incluir:**
- Descripción del sistema PianoFlows (ver FUENTE_2 completa)
- Diagrama de arquitectura (Frontend React ↔ Backend Node.js + Socket.io ↔ Base de datos PostgreSQL)
- Flujo de un evento MIDI en el Módulo Sala de Conciertos (ver sección "Flujo de un evento musical" en FUENTE_2)
- Justificación tecnológica: por qué se eligió Socket.io sobre WebSocket nativo (gestión de salas, reconexión automática, compatibilidad con fallback HTTP)

---

## 4. Metodología Experimental
**Variables del experimento (declaración formal obligatoria):**
- **Variable independiente:** Protocolo de comunicación (HTTP REST vs WebSocket/Socket.io)
- **Variables dependientes:** Latencia media (RTT en ms), latencia máxima (Jitter), varianza de latencia, consumo de CPU del servidor, consumo de RAM del servidor
- **Variables controladas:** Tamaño del payload (mismo JSON en ambos protocolos), frecuencia de envío (25 notas/seg por cliente), número de clientes concurrentes (4), condiciones de red emuladas (50ms lag + 1% drop), hardware del servidor y del cliente, versión de Node.js y Socket.io

**Diseño del experimento:**
- 2 escenarios: Escenario A (HTTP REST), Escenario B (WebSocket con Socket.io)
- 4 clientes concurrentes, 1,000 iteraciones por cliente, 100 eventos/seg totales al servidor
- Emulación de red con Clumsy (50ms lag + 1% packet loss) — ver FUENTE_1 y FUENTE_4 sección 8
- Fase de calentamiento: primeras 100 iteraciones descartadas (ver FUENTE_4 sección 7)
- Justificación de N=1,000: citar [6] (Bozakov 2013)
- Herramientas: Node.js + Express + Socket.io (servidor), axios + socket.io-client (cliente), Clumsy (emulación de red), archivos CSV para registro de resultados

---

## 5. Resultados
**Hipótesis formales (deben aparecer antes de los resultados):**
- H₀ (Nula): No existe diferencia estadísticamente significativa en la latencia máxima entre HTTP REST y WebSocket bajo condiciones de red adversas.
- H₁ (Alternativa): WebSocket presenta picos de latencia máxima significativamente menores que HTTP REST bajo condiciones de red adversas (1% packet loss).

**Datos para incluir (todos de FUENTE_1):**
- Tabla comparativa de métricas: media, varianza, máximo, mínimo, CPU, RAM de ambos protocolos
- Gráfico de líneas: eje X = iteración (1–1000), eje Y = Latencia en ms (uno por protocolo o superpuestos)
- Gráfico de caja (Box Plot): distribución completa de latencias (Q1, Mediana, Q3, Max, Outliers) para ambos protocolos
- Prueba de Welch: T=23.5997, df=7,179, p<0.0001 → Se rechaza H₀

**Resultados negativos y errores (obligatorio según la rúbrica):**
- El script de Windows no completó las 4,000 iteraciones totales; fue interrumpido por Ctrl+C tras quedarse en espera de los últimos paquetes perdidos por Clumsy
- Esto es coherente con el TCP Head-of-Line Blocking: los paquetes perdidos en WebSocket bloquearon el hilo hasta agotar el tiempo de espera
- Las muestras válidas analizadas fueron N=3,600 por protocolo (90% de la muestra objetivo), cifra estadísticamente suficiente

---

## 6. Discusión
**Contenido que debe incluir:**
- Explicar por qué HTTP tuvo menor promedio pero mayor Jitter (TCP HOL Blocking vs múltiples conexiones independientes) — ver FUENTE_4 secciones 3 y 4
- Explicar los picos de 1,318ms de HTTP (overhead del handshake en retransmisiones) — ver FUENTE_4 sección 4
- Argumentar por qué el Jitter (varianza) es la métrica correcta para música, no la latencia media — ver FUENTE_4 sección 5
- Amenazas a la validez: emulación en LAN vs internet real, uso de Socket.io (overhead adicional sobre WebSocket nativo)
- Implicación práctica: cualquier motor musical web multijugador DEBE usar WebSocket para garantizar picos acotados

---

## 7. Conclusiones y Trabajos Futuros
**Contenido que debe incluir:**
- Respuesta directa a la pregunta de investigación (usar hipótesis: se rechaza H₀, se acepta H₁)
- Principal hallazgo: WebSocket reduce picos de latencia un 56% (580ms vs 1,318ms), con p<0.0001
- Aporte del estudio: primer análisis comparativo de protocolos bajo carga específica de alta frecuencia de eventos MIDI con emulación de condiciones WiFi adversas controladas
- Condiciones bajo las cuales se obtuvo: LAN local con 50ms lag + 1% packet loss emulados
- Limitación principal: TCP Head-of-Line Blocking penaliza la latencia media de WebSocket en redes con pérdida de paquetes
- Recomendación: para motores musicales web multijugador, WebSocket es el único protocolo que garantiza picos de latencia (Jitter) acotados
- Trabajo futuro: evaluar WebTransport sobre QUIC/HTTP3, que al operar sobre UDP elimina el TCP HOL Blocking (citar [14] Caballero 2023 de FUENTE_3)

---

## Formato de texto correcto (Según PrototipoSpringer.doc, sección 2)
> ⚠️ **La plantilla Springer NO permite texto en negritas ni subrayado dentro de los párrafos normales.** Para enfatizar términos técnicos dentro del cuerpo del artículo, se debe usar *cursiva*. Por ejemplo: en lugar de **WebSocket**, escribir *WebSocket*.

- Texto principal: Times 10pt, interlineado sencillo, justificado
- Negritas: **Solo** en rótulos de tablas/figuras (`**Fig. 1.**`, `**Tabla 1.**`) y en títulos de sección
- Cursiva: para énfasis de términos técnicos en el cuerpo del texto
- Subrayado: NO permitido en ningún caso
- Código fuente en el artículo: Courier 9pt, precedido de explicación en 10pt, etiquetado como `Algoritmo N. Descripción.`

## Enlace al Repositorio (Obligatorio dentro del artículo)
El artículo debe incluir explícitamente la URL del repositorio público. El repositorio debe contener antes de la entrega:
- `README.md` con instrucciones de instalación y ejecución
- `.env.example` con la estructura de variables de entorno (sin valores reales)
- Archivo `LICENSE`
- `latencia_test.js` (el script del experimento)
- Los archivos `resultados_latencia_http.csv` y `resultados_latencia_ws.csv` (evidencia de ejecución)
- Instrucciones de cómo reproducir el experimento

## Evidencias de Ejecución (Entregable obligatorio)
Además del artículo PDF, el profesor pide evidencias de ejecución de los escenarios. Preparar:
1. Captura de pantalla de la terminal del servidor Linux mostrando los logs (`POST /api/test/note` y conexiones WebSocket)
2. Captura de pantalla de la consola de Windows ejecutando `node latencia_test.js`
3. Captura de pantalla de los archivos CSV generados con datos
