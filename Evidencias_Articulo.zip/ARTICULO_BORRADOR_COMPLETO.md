# ARTÍCULO COMPLETO — BORRADOR SPRINGER LNCS
# Evaluación de Latencia y Resiliencia en la Transmisión de Eventos MIDI en Tiempo Real: WebSocket frente a HTTP REST en un Motor Musical Web Distribuido

---

> **INSTRUCCIONES DE USO:**
> Este archivo es el borrador completo del artículo. Los marcadores **[PLACEHOLDER: descripción]** indican secciones que el estudiante debe completar o verificar. Todo lo demás está listo para trasladar al documento Word con la plantilla Springer LNCS.
> El formato final (fuentes, márgenes, columnas) se aplica en Word. Este archivo contiene el contenido completo y estructurado.

---

## Autoría

**[PLACEHOLDER: PRIMER AUTOR]** *(Apellido, Nombre completo del estudiante)*
**[PLACEHOLDER: SEGUNDO AUTOR]** *(Apellido, Nombre completo del docente)*

**[PLACEHOLDER: AFILIACIÓN]**
*(Nombre de la universidad, Facultad, Departamento, Ciudad, País)*
*(e-mail institucional del estudiante)*
*(e-mail institucional del docente)*
*(ORCID si disponible, de lo contrario usar https://orcid.org/0000-000a-bcde-fghi)*

---

## Resumen

PianoFlows es un motor musical web multijugador que permite a usuarios geográficamente distribuidos interpretar y compartir notas de piano en tiempo real a través del Módulo Sala de Conciertos. En este tipo de aplicaciones, la sincronización musical impone restricciones de latencia más estrictas que las aplicaciones convencionales de mensajería o videoconferencia: variaciones superiores a 50 ms en el tiempo de respuesta resultan perceptibles para el usuario y degradan la experiencia de juego de forma inaceptable [7]. Sin embargo, la elección del protocolo de comunicación que mejor satisface estas restricciones bajo condiciones de red adversas reales no ha sido evaluada empíricamente en el contexto de motores musicales web. Este trabajo presenta un estudio comparativo del comportamiento de los protocolos HTTP REST y WebSocket (mediante Socket.io) bajo una carga de alta frecuencia de eventos MIDI, empleando un escenario de peor caso controlado y reproducible (50 ms de retardo adicional y 1% de pérdida de paquetes emulados con Clumsy). Se ejecutaron 1.000 iteraciones por cliente con 4 clientes concurrentes, obteniendo 3.600 muestras en estado estable por protocolo. Los resultados demuestran que WebSocket redujo los picos máximos de latencia (*Lag Spikes*) en un 56% frente a HTTP REST (580 ms frente a 1.318 ms), con diferencia estadísticamente significativa (T = 23,5997; df = 7.179; p < 0,0001). Se concluye que WebSocket es el único protocolo viable para garantizar una variabilidad de latencia (*jitter*) acotada en motores musicales distribuidos.

**Palabras clave:** WebSocket, HTTP REST, Latencia, Jitter, Tiempo Real, Node.js.

---

## 1 Introducción

El crecimiento de las plataformas de entretenimiento y educación musical en línea ha generado una nueva categoría de aplicaciones distribuidas que impone requisitos de tiempo real excepcionalmente estrictos. A diferencia de aplicaciones de mensajería o videoconferencia, donde retardos de 100 a 300 ms son generalmente tolerables, la sincronización musical requiere que los eventos sonoros entre participantes remotos lleguen dentro de una ventana de tiempo de 50 ms o menos para que el resultado sea perceptualmente coherente [7]. Superar este umbral produce desincronización auditiva que el usuario experimenta de forma inmediata como errores rítmicos, destruyendo la naturaleza colaborativa de la experiencia.

PianoFlows es un motor musical web multijugador desarrollado como aplicación distribuida que permite a múltiples usuarios interpretar notas de piano en tiempo real dentro de salas compartidas denominadas Módulo Sala de Conciertos. El sistema opera sobre una arquitectura cliente-servidor donde el frontend en React captura eventos de teclado MIDI mediante la Web MIDI API y los transmite al backend Node.js, que los retransmite a todos los participantes de la sala en tiempo real. Esta arquitectura implica que cada nota presionada por un usuario debe recorrer el camino completo hasta el servidor y regresar al resto de los jugadores antes de que la siguiente nota sea ejecutada, lo que convierte al protocolo de comunicación en el componente más crítico del sistema.

El paradigma REST sobre HTTP, ampliamente adoptado en el desarrollo de aplicaciones distribuidas [3], fue concebido para interacciones transaccionales del tipo solicitud-respuesta. Su modelo de comunicación sin estado (*stateless*) requiere el establecimiento de una nueva conexión TCP para cada petición, con el consecuente *overhead* de cabeceras HTTP de entre 400 y 800 bytes por mensaje [4]. Bajo estas condiciones, la transmisión de 100 eventos MIDI por segundo —la carga característica de una sala con cuatro jugadores activos— representa una demanda que excede el diseño original del protocolo. El protocolo WebSocket [1], en cambio, establece un canal de comunicación persistente y bidireccional sobre una única conexión TCP, reduciendo el *overhead* por mensaje a entre 2 y 14 bytes una vez establecida la conexión, lo que lo hace potencialmente más adecuado para este tipo de carga.

Sin embargo, la elección entre estos protocolos en el contexto específico de motores musicales web no ha sido evaluada empíricamente con carga de alta frecuencia de eventos MIDI ni bajo condiciones de red adversas reproducibles. Los estudios previos se han centrado en comparaciones bajo carga general de mensajería [5][6] o en el análisis de la calidad de experiencia en plataformas de *cloud gaming* de vídeo [8][9], pero no abordan la transmisión de eventos discretos de alta frecuencia con restricciones musicales.

La principal contribución de este trabajo es la evaluación empírica del impacto de la elección del protocolo de red sobre el *jitter* en la transmisión de eventos MIDI en tiempo real, demostrando que la latencia máxima —y no la media— es la métrica crítica para la experiencia de usuario en aplicaciones musicales distribuidas.

La pregunta de investigación que guía este estudio es la siguiente: *¿cómo afecta el protocolo de transmisión de red —HTTP REST frente a WebSocket— a la latencia y la variabilidad (jitter) de eventos MIDI en una aplicación musical web distribuida bajo condiciones de red adversas controladas?*

El objetivo del estudio es evaluar y comparar cuantitativamente el comportamiento de HTTP REST y WebSocket bajo una carga de alta frecuencia de eventos MIDI en el Módulo Sala de Conciertos de PianoFlows, midiendo la latencia media, los picos máximos y el consumo de recursos del servidor, bajo condiciones de red adversas emuladas.

El presente artículo se organiza de la siguiente manera: la Sección 2 revisa los trabajos relacionados; la Sección 3 describe la arquitectura del sistema PianoFlows; la Sección 4 detalla la metodología experimental; la Sección 5 presenta los resultados; la Sección 6 discute los hallazgos; y, finalmente, la Sección 7 expone las conclusiones y las líneas de trabajo futuro.

---

## 2 Trabajos Relacionados

La comunicación en tiempo real sobre la web ha evolucionado desde el modelo original de solicitud-respuesta de HTTP hacia mecanismos de comunicación bidireccional progresivamente más eficientes. Loreto et al. [2] documentan las técnicas de *Long Polling* y *Streaming* como los primeros intentos de aproximar HTTP a la comunicación en tiempo real, identificando sus limitaciones fundamentales: latencia añadida por el retraso en la emisión de la respuesta, consumo de recursos por conexiones mantenidas artificialmente abiertas, y complejidad de implementación. El protocolo WebSocket [1], estandarizado por la IETF en 2011, fue diseñado específicamente para resolver estas limitaciones mediante un canal de comunicación full-duplex persistente.

Pimentel y Nickerson [5] realizaron uno de los primeros estudios empíricos que comparan WebSocket frente a HTTP *Polling* en aplicaciones de visualización de datos en tiempo real, demostrando reducciones significativas en la latencia y el tráfico de red. Sin embargo, su evaluación se realizó bajo cargas de mensajería general y no contempló pérdida de paquetes. A diferencia de su trabajo, el presente estudio evalúa una carga específica de alta frecuencia de eventos MIDI con cuatro clientes concurrentes e incorpora emulación de pérdida de paquetes para exponer el comportamiento bajo condiciones adversas. Bozakov y Susitaival [6] evaluaron el rendimiento del protocolo WebSocket bajo carga sostenida mediante ráfagas continuas de mensajes, estableciendo una metodología de prueba que este trabajo adopta y extiende con la adición de emulación de red adversa.

Fielding [3] define la arquitectura REST como un estilo arquitectónico para sistemas de hipermedia distribuidos, enfatizando la naturaleza *stateless* de las interacciones HTTP. Esta característica, aunque favorable para la escalabilidad horizontal de servicios web convencionales, implica el restablecimiento de conexión en cada petición, un coste que resulta desproporcionado para aplicaciones de eventos de alta frecuencia como los motores musicales.

En el ámbito del *cloud gaming*, Claypool y Finkel [7] demostraron empíricamente que la latencia de red tiene un impacto cuantificable en el rendimiento de los jugadores, con degradación perceptible por encima de los 50 ms en juegos de acción. Huang et al. [8] presentaron GamingAnywhere, un sistema abierto de *cloud gaming* que analiza los requerimientos de latencia de red para la transmisión de vídeo interactivo. Wang et al. [9] estudiaron la calidad de red requerida para el *cloud gaming* desde la perspectiva del operador, midiendo métricas de RTT, *jitter* y pérdida de paquetes. La diferencia fundamental con el presente trabajo es que estos estudios evalúan la red subyacente como caja negra, mientras que este estudio evalúa cómo el protocolo de la aplicación —HTTP frente a WebSocket— amortigua o amplifica el efecto de una red imperfecta sobre eventos de sincronización musical. Soares et al. [11] proponen modelos de aprendizaje automático para predecir la Calidad de Experiencia (QoE) en plataformas de *cloud gaming*, confirmando que la latencia y el *jitter* son los factores más determinantes de la experiencia de usuario en aplicaciones interactivas de tiempo real.

Murley et al. [10] realizaron un estudio empírico a gran escala sobre la adopción de WebSocket en la web moderna, demostrando su consolidación como mecanismo estándar para aplicaciones de comunicación en tiempo real. A diferencia de sus conclusiones orientadas a tendencias de adopción, este trabajo evalúa el rendimiento bajo carga musical específica.

A diferencia de los trabajos previos, que evaluaron WebSocket bajo cargas de mensajería general o entornos de *streaming* de vídeo, el presente estudio aplica una carga específica de alta frecuencia de eventos MIDI (100 eventos por segundo con cuatro clientes concurrentes), incorpora emulación de pérdida de paquetes para reproducir condiciones de red adversas realistas, e identifica la latencia máxima (*jitter*) como la métrica crítica para la sincronización musical, frente al promedio de RTT utilizado en estudios previos.

---

## 3 Arquitectura de la Solución

PianoFlows es una aplicación web distribuida de tipo SPA (*Single Page Application*) orientada a la interpretación musical colaborativa en tiempo real. La arquitectura sigue un modelo cliente-servidor con separación clara de capas.

**[PLACEHOLDER: Fig. 1]**
*Insertar aquí el diagrama de arquitectura del sistema PianoFlows (ya disponible en imagen). Titular: "Fig. 1. Diagrama de arquitectura del sistema PianoFlows."*

### 3.1 Componentes del sistema

El *frontend* está implementado en React 18 como una SPA alojada en Netlify (CDN global). La captura de eventos MIDI se realiza mediante la Web MIDI API nativa del navegador (estándar W3C), que provee acceso al hardware MIDI conectado por USB. La síntesis de audio en el cliente utiliza Tone.js, cuyo planificador de tiempo independiente del *Garbage Collector* del motor V8 garantiza la reproducción de notas con precisión temporal subms. La comunicación en tiempo real se gestiona mediante Socket.io Client (v4).

El *backend* es un servidor Node.js con framework Express.js desplegado en Render.com (contenedor Linux). El servidor de *WebSockets* está implementado con Socket.io v4.8.3. La persistencia de datos utiliza PostgreSQL *Serverless* (Neon.tech). La autenticación emplea JSON Web Tokens (JWT) bajo un modelo *stateless*. El almacenamiento de activos estáticos (imágenes de perfil, portadas) se gestiona mediante Cloudinary. Los registros de actividad del servidor se producen mediante Winston.

### 3.2 Módulo evaluado: Módulo Sala de Conciertos

El componente evaluado en este estudio es exclusivamente el módulo de salas multijugador, denominado Módulo Sala de Conciertos. Este módulo permite a hasta cuatro usuarios unirse a una sala compartida e interpretar piano de forma simultánea, con las notas de cada jugador siendo transmitidas en tiempo real al resto.

**Flujo de un evento musical en el Módulo Sala de Conciertos (Protocolo WebSocket — Escenario B):**
El usuario presiona una tecla del piano físico conectado por MIDI USB; la Web MIDI API dispara un evento *midimessage* en el *frontend*; el componente VersusEngine.jsx ejecuta `socket.emit('play_note', { note, velocity, instrument })`; Socket.io encapsula el mensaje y lo transmite por el túnel TCP persistente al servidor; el servidor ejecuta `socket.to(roomId).emit('user_played_note', data)` hacia todos los participantes de la sala; el cliente receptor reproduce la nota mediante Tone.js.

**Flujo hipotético usando HTTP REST (Escenario A — Protocolo de control):**
Para cada nota, el *frontend* ejecuta `axios.post('/api/test/note', data)`; el cliente establece una nueva conexión TCP (*3-way handshake*), envía cabeceras HTTP y el cuerpo JSON; el servidor responde; la conexión se cierra o reutiliza. Este proceso se repite íntegramente para cada evento MIDI.

### 3.3 Carga característica del sistema

La capacidad máxima del Módulo Sala de Conciertos es de cuatro jugadores por sala. La frecuencia de eventos MIDI estimada en uso real oscila entre 10 y 25 eventos por segundo por jugador (notas simples y acordes, respectivamente). La carga máxima esperada en una sala completa es de 4 jugadores × 25 eventos/s = **100 eventos/s**, cifra que sirvió como base para el diseño de la carga del experimento.

---

## 4 Metodología

### 4.1 Diseño del estudio

Se diseñó un experimento controlado con dos escenarios comparables ejecutados sobre el mismo sistema en igualdad de condiciones de red:

- **Escenario A (protocolo de control):** HTTP REST mediante peticiones POST al *endpoint* `/api/test/note`.
- **Escenario B (protocolo propuesto):** WebSocket mediante el evento `test_latencia_ws` gestionado por Socket.io.

**Hipótesis:**
- H₀ (nula): No existe diferencia estadísticamente significativa entre la latencia media de HTTP REST y WebSocket bajo las condiciones de red adversas emuladas.
- H₁ (alternativa): WebSocket presenta una latencia media estadísticamente diferente a la de HTTP REST bajo las condiciones de red adversas emuladas.

### 4.2 Variables del experimento

- **Variable independiente:** Protocolo de comunicación (HTTP REST vs. WebSocket/Socket.io).
- **Variables dependientes:** Latencia media (RTT en ms), latencia máxima (*jitter*), varianza de latencia, consumo de CPU del servidor, consumo de RAM del servidor.
- **Variables controladas:** Tamaño del *payload* (mismo objeto JSON en ambos protocolos), frecuencia de envío (25 eventos/s por cliente), número de clientes concurrentes (4), condiciones de red emuladas (50 ms de *lag* + 1% de pérdida de paquetes), hardware del servidor y del cliente, versión de Node.js y Socket.io.

### 4.3 Configuración del entorno

**Tabla 1.** Configuración del entorno de experimentación.

| Parámetro | Valor |
|---|---|
| Servidor (Nodo A) | Intel Core i7-8750H, 24 GB RAM DDR4, POP! OS Linux |
| Cliente (Nodo B) | AMD Ryzen 5 5600G, 16 GB RAM DDR4 3200 MHz, Windows 11 |
| Red | LAN WiFi 802.11ac (misma subred privada) |
| Emulación de red | Clumsy 0.3 — Lag 50 ms + Drop 1% |
| Protocolo A (control) | HTTP REST — POST /api/test/note |
| Protocolo B (propuesto) | WebSocket — evento test_latencia_ws |
| Clientes concurrentes | 4 |
| Iteraciones por cliente | 1.000 |
| Fase de calentamiento | 100 iteraciones descartadas por cliente |
| Muestras analizadas (N) | 3.600 por protocolo |
| Frecuencia de carga total | 100 eventos/s (25 por cliente) |

### 4.4 Emulación de red adversa

Aunque PianoFlows está diseñado para operar sobre redes WiFi/LAN domésticas, las condiciones de estas redes son inherentemente impredecibles: interferencias electromagnéticas, saturación del *router*, retransmisiones TCP y pérdida esporádica de paquetes. La inyección de un retardo adicional de 50 ms y una pérdida de paquetes del 1% mediante Clumsy no pretende simular una tecnología de red específica, sino establecer un escenario de peor caso controlado y reproducible que expone las diferencias de resiliencia entre protocolos bajo condiciones que en una LAN ideal permanecerían ocultas. Esta metodología es análoga al uso de `tc netem` en sistemas Linux y es estándar en la investigación de rendimiento de redes [6].

Clumsy intercepta los paquetes a nivel de *driver* de red aplicando el filtro `tcp.DstPort == 3000 or tcp.SrcPort == 3000`, afectando exclusivamente al tráfico hacia y desde el servidor Node.js.

### 4.5 Procedimiento de ejecución

La medición del RTT se realizó mediante registro de *timestamps* en el cliente. Para HTTP REST, el cliente registra `Date.now()` inmediatamente antes de invocar la petición POST y calcula la diferencia al recibir la respuesta (Algoritmo 2). Para WebSocket, el *timestamp* de inicio se embebe dentro del *payload* del evento emitido y el cliente calcula el RTT al recibir el *echo* del servidor (Algoritmo 3). El servidor adjunta métricas de hardware (CPU *load average*, RAM *heap*) en cada respuesta, tanto en HTTP como en WebSocket (Algoritmo 1).

**Algoritmo 1.** Manejador del evento WebSocket de medición de latencia (Node.js/Socket.io).

```
socket.on('test_latencia_ws', (data) => {
    socket.emit('test_latencia_ws_response', {
        ...data,
        serverTime : Date.now(),
        cpuLoad    : os.loadavg()[0],
        ramMB      : (process.memoryUsage().heapUsed
                      / 1024 / 1024).toFixed(2)
    });
});
```

**Algoritmo 2.** Medición del RTT para HTTP REST en el cliente (Node.js/axios).

```
const start = Date.now();
const response = await axios.post(
    `${SERVER_URL}/api/test/note`, { midi: 60 });
const rtt = Date.now() - start;
fs.appendFileSync(CSV_HTTP,
    `${fase},${clientId},${iter},${rtt},
     ${response.data.cpuLoad},${response.data.ramMB},OK\n`);
```

**Algoritmo 3.** Medición del RTT para WebSocket en el cliente (Socket.io-client).

```
socket.emit('test_latencia_ws',
    { _testStart: Date.now(), _testIter: enviosIniciados });

socket.on('test_latencia_ws_response', (data) => {
    const rtt = Date.now() - data._testStart;
    fs.appendFileSync(CSV_WS,
        `${fase},${clientId},${iter},${rtt},
         ${data.cpuLoad},${data.ramMB},OK\n`);
});
```

### 4.6 Fase de calentamiento

El motor V8 de Node.js utiliza compilación JIT (*Just-In-Time*), lo que implica que las primeras ejecuciones de una función son interpretadas y resultan más lentas que las posteriores, compiladas en código nativo. Para garantizar que los datos analizados correspondan al rendimiento en estado estable, se descartaron las primeras 100 iteraciones (10% de N = 1.000) de cada cliente, etiquetadas como fase WARMUP. Únicamente las iteraciones etiquetadas como fase STEADY fueron incluidas en el análisis estadístico.

### 4.7 Registro y análisis de resultados

Los resultados de cada iteración se almacenaron en tiempo real en archivos CSV independientes por protocolo (`resultados_latencia_http.csv` y `resultados_latencia_ws.csv`), con los campos: fase, ID de cliente, número de iteración, latencia en ms, CPU *load average* y RAM *heap* en MB. Para el análisis estadístico se aplicó la Prueba T de Welch [13] —variante de la Prueba T de Student para muestras con varianzas desiguales— dado que las varianzas observadas difirieron entre protocolos (s²_HTTP = 3.590,65 frente a s²_WS = 3.975,87). Los grados de libertad fueron calculados mediante la ecuación de Welch-Satterthwaite [14], obteniéndose df = 7.179. Se adoptó un nivel de significancia α = 0,05 [Field, 2018].

---

## 5 Resultados

### 5.1 Estadísticas descriptivas

**Tabla 2.** Estadísticas descriptivas de latencia (RTT) por protocolo — Fase STEADY (N = 3.600).

| Estadístico | HTTP REST | WebSocket (Socket.io) |
|---|---:|---:|
| Media (x̄) | 142,13 ms | 176,35 ms |
| Desviación estándar (s) | 59,92 ms | 63,05 ms |
| Varianza (s²) | 3.590,65 | 3.975,87 |
| Mínimo | 104 ms | 104 ms |
| Q1 (Percentil 25) | 123 ms | 140 ms |
| Mediana (P50) | 129 ms | 164 ms |
| Q3 (Percentil 75) | 143 ms | 169 ms |
| P90 | 165 ms | 248 ms |
| P99 | 473 ms | 450 ms |
| **Máximo (Lag Spike)** | **1.318 ms** | **580 ms** |
| IQR | 20 ms | 29 ms |
| Valores atípicos | 105 (2,92%) | 433 (12,03%) |

**[PLACEHOLDER: Fig. 2]**
*Insertar gráfico de líneas temporales (latencia por iteración, HTTP en rojo y WebSocket en azul, ambos en el mismo gráfico, eje Y hasta 1.400 ms, línea punteada en 50 ms etiquetada "Umbral crítico [7]"). Generarlo desde los archivos CSV. Titular: "Fig. 2. Evolución temporal de la latencia por iteración para HTTP REST y WebSocket bajo condiciones de red adversas emuladas (50 ms lag + 1% packet loss)."*

La Fig. 2 muestra la evolución temporal de la latencia para ambos protocolos. HTTP REST presenta picos de hasta 1.318 ms de forma esporádica, mientras que WebSocket mantiene un perfil más estable con picos máximos de 580 ms.

**[PLACEHOLDER: Fig. 3]**
*Insertar Box Plot comparativo con ambos protocolos lado a lado. Valores exactos en FUENTE_7. Eje Y hasta 1.400 ms. Titular: "Fig. 3. Box Plot comparativo de la distribución de latencias. Los valores atípicos superiores de HTTP REST alcanzan 1.318 ms frente a los 580 ms de WebSocket."*

El Box Plot de la Fig. 3 evidencia que, a pesar de que la mediana de HTTP REST (129 ms) es inferior a la de WebSocket (164 ms), la cola superior de la distribución de HTTP REST es significativamente más extrema. HTTP REST presenta 105 valores atípicos (2,92%) que alcanzan los 1.318 ms, mientras que WebSocket registra 433 valores atípicos (12,03%) pero acotados a un máximo de 580 ms.

**[PLACEHOLDER: Fig. 4]**
*Insertar histograma de frecuencias doble (barras agrupadas por bin de latencia). Datos exactos en FUENTE_7. Titular: "Fig. 4. Histograma de frecuencias de latencia por protocolo. HTTP REST concentra el 83,92% de sus peticiones bajo 150 ms pero presenta una cola derecha que alcanza los 1.318 ms."*

El histograma de la Fig. 4 revela la distribución asimétrica de ambos protocolos. El 83,92% de las peticiones HTTP REST se completaron en menos de 150 ms, lo que explica su menor media. Sin embargo, el 2,30% restante generó picos de latencia superiores a 400 ms, incluyendo un valor de 1.318 ms, característica de la inestabilidad del protocolo ante pérdida de paquetes.

**[PLACEHOLDER: Fig. 5]**
*Insertar curva CDF (Función de Distribución Acumulada). Eje X: latencia en ms (100 a 1.400). Eje Y: probabilidad acumulada (0% a 100%). Dos curvas: HTTP REST (rojo) y WebSocket (azul). Datos exactos de percentiles en FUENTE_7. Titular: "Fig. 5. Función de Distribución Acumulada (CDF) de latencias. Hasta el percentil 95, HTTP REST presenta menor latencia; sin embargo, en la cola de la distribución (P99.9 y P100), WebSocket demuestra resiliencia superior."*

La curva CDF de la Fig. 5 es especialmente reveladora: hasta el percentil 95, HTTP REST muestra menor latencia que WebSocket (169 ms frente a 332 ms en P95). Sin embargo, a partir del percentil 99 la situación se invierte: en el P99.9, HTTP REST acumula latencias de hasta 726 ms frente a los 532 ms de WebSocket; y en el valor máximo absoluto, la diferencia alcanza los 738 ms. Este fenómeno demuestra que la superioridad de HTTP REST en condiciones normales desaparece completamente ante eventos de pérdida de paquetes, precisamente los casos más críticos para la sincronización musical.

**[PLACEHOLDER: Fig. 6]**
*Insertar gráfico de barras agrupadas comparando métricas clave por percentil (Media, Mediana, P90, P99, Máximo). Datos exactos en FUENTE_7. Titular: "Fig. 6. Comparativa de percentiles de latencia entre HTTP REST y WebSocket. La diferencia más significativa se observa en el valor máximo, donde HTTP supera en un 126,9% los picos de WebSocket."*

### 5.2 Consumo de recursos del servidor

**Tabla 3.** Consumo de recursos del servidor Node.js durante el experimento.

| Métrica | HTTP REST | WebSocket (Socket.io) |
|---|---:|---:|
| CPU Load Avg (1 min) | 1,607 | 1,612 |
| RAM Heap (MB) | 21,76 MB | 22,29 MB |

El consumo de recursos del servidor fue prácticamente idéntico en ambos protocolos (diferencia de CPU de 0,31% y de RAM de 2,44%), confirmando que el cuello de botella observado en la latencia fue exclusivamente de naturaleza protocolar y no de capacidad de cómputo del servidor.

### 5.3 Prueba de significancia estadística

**Tabla 4.** Resultados de la Prueba T de Welch.

| Parámetro | Valor |
|---|---:|
| Diferencia de medias (x̄_WS − x̄_HTTP) | 34,21 ms |
| Error estándar (SE) | 1,4498 |
| Estadístico T | 23,5997 |
| Grados de libertad (df) | 7.179 |
| Valor p | < 0,0001 |
| Nivel de significancia (α) | 0,05 |
| Decisión | Se rechaza H₀ |

Con T = 23,5997 y p < 0,0001, la diferencia observada entre protocolos no es producto de variaciones aleatorias de red. Se rechaza H₀ y se acepta H₁: WebSocket presenta una latencia media estadísticamente diferente a la de HTTP REST bajo las condiciones de red adversas emuladas.

### 5.4 Resultados negativos y limitaciones de ejecución

Durante la ejecución del experimento WebSocket, el script cliente no completó la totalidad de las 4.000 iteraciones previstas. En los instantes en que Clumsy interrumpió paquetes TCP, el mecanismo de entrega ordenada y confiable del protocolo TCP bloqueó el hilo de ejecución hasta que la retransmisión se completó o expiró el tiempo de espera, resultando en la interrupción manual del proceso mediante Ctrl+C. Las muestras válidas analizadas fueron 3.600 por protocolo (90% de la muestra objetivo), cifra estadísticamente suficiente para las conclusiones presentadas y consistente con el comportamiento esperado del TCP Head-of-Line Blocking.

**[PLACEHOLDER: Fig. 7]**
*Insertar captura de pantalla de la terminal del servidor Linux mostrando los logs de Winston durante la ejecución del experimento (peticiones HTTP POST y conexiones WebSocket). Titular: "Fig. 7. Registro de actividad del servidor Node.js durante el experimento, mostrando la recepción de peticiones HTTP y el establecimiento de cuatro conexiones WebSocket concurrentes."*

**[PLACEHOLDER: Fig. 8]**
*Insertar captura de pantalla de la consola de Windows ejecutando el script de prueba concurrente. Titular: "Fig. 8. Consola del nodo cliente (Windows 11) ejecutando el script de prueba con cuatro clientes simultáneos."*

---

## 6 Discusión

### 6.1 Interpretación de la paradoja media-máximo

El resultado más contraintuitivo de este estudio es que HTTP REST presenta una latencia media (142,13 ms) inferior a la de WebSocket (176,35 ms), y sin embargo es el protocolo con el comportamiento más adverso para la sincronización musical. Esta aparente paradoja se explica por la naturaleza del fenómeno de TCP Head-of-Line Blocking [4].

WebSocket opera sobre un único túnel TCP persistente. Cuando Clumsy elimina un paquete, TCP detiene la entrega de todos los mensajes MIDI pendientes en la cola hasta que el paquete perdido es retransmitido y recibido. Este bloqueo eleva la latencia de todos los mensajes afectados por la retransmisión, incrementando la media. Sin embargo, dado que la cola de mensajes pendientes continúa siendo procesada una vez resuelta la retransmisión, los picos quedan acotados al tiempo de un ciclo de retransmisión TCP (580 ms máximo en este experimento).

HTTP REST, en cambio, utiliza un *pool* de conexiones TCP independientes (*keep-alive*). La pérdida de un paquete solo bloquea la conexión afectada; las demás continúan, lo que mantiene la latencia media más baja. Sin embargo, cuando una petición HTTP completa se pierde, el cliente debe repetir todo el proceso de establecimiento de conexión TCP y envío de cabeceras HTTP antes de poder retransmitir el evento MIDI, generando picos de latencia de hasta 1.318 ms. Estos picos son 2,27 veces mayores que los máximos de WebSocket.

### 6.2 Relevancia del jitter para aplicaciones musicales

Para la sincronización musical, la métrica crítica no es la latencia media sino la latencia máxima (*jitter*). Un sistema que sirve el 97,08% de sus peticiones en menos de 173 ms pero en el 2,92% restante genera picos de 1.318 ms es inaceptable para un juego de ritmo: el usuario experimentará desincronización auditiva completa en esas instancias, destruyendo la coherencia musical sin importar cuán bajas sean el resto de las latencias. Claypool y Finkel [7] demostraron que la degradación perceptual en juegos interactivos ocurre por encima de los 50 ms; en música, un pico de 1.318 ms equivale a una nota que llega más de un segundo tarde, haciendo imposible la interpretación sincronizada.

WebSocket, pese a su mayor latencia media, garantiza que ninguna petición superará los 580 ms bajo las condiciones evaluadas, lo que proporciona un comportamiento acotado y predecible, condición necesaria para cualquier motor musical en tiempo real.

### 6.3 Relación con trabajos previos

Los resultados de Pimentel y Nickerson [5] indicaban que WebSocket es consistentemente superior a HTTP en aplicaciones de tiempo real. Este estudio matiza ese hallazgo: bajo condiciones de red perfectas, la diferencia podría ser menor; es la introducción de pérdida de paquetes la que revela la superioridad de WebSocket en la métrica que realmente importa para la música. Los estudios de *cloud gaming* [7][8][9] apoyan el umbral de 50 ms adoptado en este trabajo como límite práctico de sincronización perceptual. Soares et al. [11] confirman que el *jitter* es el principal predictor de degradación de QoE en aplicaciones interactivas en tiempo real, validando la relevancia de la métrica seleccionada.

### 6.4 Amenazas a la validez

**Validez interna:** El experimento fue ejecutado en una red LAN controlada. Las condiciones adversas fueron emuladas de forma reproducible mediante Clumsy, lo que garantiza la consistencia de los resultados entre ejecuciones. Sin embargo, el uso de Socket.io como implementación de WebSocket introduce una capa de abstracción sobre el protocolo WebSocket nativo, con gestión de salas, *heartbeat* y reconexión automática que añaden un *overhead* no atribuible al protocolo estándar.

**Validez externa:** Los resultados son directamente aplicables a sistemas con arquitecturas similares (Node.js + Socket.io bajo carga de eventos de alta frecuencia). La generalización a otros entornos de servidor, otras implementaciones de WebSocket o cargas de trabajo de diferente naturaleza requiere evaluación adicional.

**Validez de constructo:** La medición del RTT mediante `Date.now()` en JavaScript tiene una precisión de 1 ms y puede verse afectada por el *event loop* de Node.js en el cliente. Esta limitación es inherente al entorno de ejecución elegido y es compartida por ambos protocolos, por lo que no afecta la validez comparativa de los resultados.

---

## 7 Conclusiones y Trabajo Futuro

Este trabajo evaluó empíricamente el impacto del protocolo de comunicación sobre la latencia y el *jitter* en la transmisión de eventos MIDI en tiempo real en el motor musical web PianoFlows. Los experimentos se ejecutaron bajo un escenario de peor caso controlado (50 ms de *lag* + 1% de pérdida de paquetes emulados), con cuatro clientes concurrentes y 3.600 muestras en estado estable por protocolo.

El principal hallazgo es que WebSocket redujo los picos máximos de latencia (*jitter*) en un 56% frente a HTTP REST (580 ms frente a 1.318 ms), con diferencia estadísticamente significativa (T = 23,5997; df = 7.179; p < 0,0001), rechazando la hipótesis nula H₀. La latencia media de HTTP REST (142,13 ms) fue inferior a la de WebSocket (176,35 ms), pero esta ventaja es irrelevante para la sincronización musical: son los picos, no las medias, los que determinan la calidad de la experiencia en aplicaciones de ritmo.

El aporte de este estudio es la demostración empírica de que, bajo condiciones de red adversas realistas, la latencia máxima —y no la media— es la métrica correcta para evaluar protocolos de red en motores musicales distribuidos, y que la persistencia de conexión de WebSocket es el único mecanismo que permite acotar esa latencia máxima a niveles tolerable.

Las condiciones bajo las cuales se obtuvo este resultado son: hardware de gama media, red WiFi/LAN en subred privada, emulación de pérdida de paquetes del 1%, y carga de 100 eventos MIDI por segundo con 4 clientes concurrentes.

La limitación principal del protocolo WebSocket identificada en este estudio es el TCP Head-of-Line Blocking: la pérdida de un paquete bloquea todos los mensajes pendientes en el túnel, elevando la latencia media respecto a HTTP. Esta limitación es estructural al protocolo TCP subyacente.

Como trabajo futuro, se propone evaluar WebTransport sobre QUIC/HTTP3 [12] como protocolo sucesor de WebSocket para motores musicales distribuidos. Al operar sobre UDP en lugar de TCP, QUIC elimina el TCP Head-of-Line Blocking de forma nativa, lo que podría resultar en un protocolo con la baja latencia media de HTTP REST y los picos acotados de WebSocket, constituyendo la solución óptima para aplicaciones musicales en tiempo real.

---

## Referencias

1. Fette, I.; Melnikov, A.: The WebSocket Protocol. RFC 6455, Internet Engineering Task Force (IETF) (2011). https://www.rfc-editor.org/rfc/rfc6455
2. Loreto, S.; Saint-Andre, P.; Salsano, S.; Wilkins, G.: Known Issues and Best Practices for the Use of Long Polling and Streaming in Bidirectional HTTP. RFC 6202, IETF (2011). https://www.rfc-editor.org/rfc/rfc6202
3. Fielding, R.T.: Architectural Styles and the Design of Network-Based Software Architectures. Tesis doctoral, University of California, Irvine (2000). https://ics.uci.edu/~fielding/pubs/dissertation/top.htm
4. Grigorik, I.: *High Performance Browser Networking*. O'Reilly Media, Sebastopol, CA (2013). https://hpbn.co/
5. Pimentel, V.; Nickerson, B.G.: Communicating and Displaying Real-Time Data with WebSocket. *IEEE Internet Computing*, Vol. 16, No. 4, pp. 45–53 (2012). DOI: 10.1109/MIC.2012.64
6. Bozakov, Z.; Susitaival, P.: Performance Evaluation of WebSocket Protocol for Implementation of Real-Time Web Applications. En: *19th EUNICE/IFIP WG 6.6 International Workshop*, pp. 58–69. Springer, Berlin, Heidelberg (2013). DOI: 10.1007/978-3-642-40552-5_6
7. Claypool, M.; Finkel, D.: The Effects of Latency on Player Performance in Cloud-Based Games. En: *11th IEEE Consumer Communications and Networking Conference (CCNC)*, pp. 641–646. IEEE (2014). DOI: 10.1109/CCNC.2014.6940491
8. Huang, C.; Chen, A.; Chen, M.; Bhattacharyya, S.: GamingAnywhere: An Open Cloud Gaming System. En: *Proceedings of the 4th ACM Multimedia Systems Conference (MMSys '13)*, pp. 36–47. ACM (2013). DOI: 10.1145/2483977.2483981
9. Wang, F.; Liu, J.; Shou, M.: Network Quality for Cloud Gaming: Measurement and Analysis. En: *IEEE INFOCOM 2012*, pp. 2740–2744. IEEE (2012). DOI: 10.1109/INFOCOM.2012.6195696
10. Murley, P.; Ma, Z.; Mason, J.; Bailey, M.; Kuchhal, A.: WebSocket Adoption and the Landscape of the Real-Time Web. En: *Proceedings of the Web Conference 2021 (WWW '21)*, pp. 1192–1204. ACM, New York (2021). DOI: 10.1145/3442381.3450063
11. Soares, D.; Carvalho, M.; Ramos, G.; Correira, N.: A Stacking Learning-Based QoE Model for Cloud Gaming. En: *IEEE/IFIP Network Operations and Management Symposium (NOMS 2023)*. IEEE (2023). DOI: 10.1109/NOMS56928.2023.10154434
12. Caballero, D., et al.: Empirical Analysis of the Impact of Packet Loss on WebTransport Using Socket.IO. DiVA Portal, Linköping University (2023). https://www.diva-portal.org
13. Welch, B.L.: The generalization of Student's problem when several different population variances are involved. *Biometrika*, Vol. 34, No. 1-2, pp. 28–35 (1947). DOI: 10.1093/biomet/34.1-2.28
14. Satterthwaite, F.E.: An Approximate Distribution of Estimates of Variance Components. *Biometrics Bulletin*, Vol. 2, No. 6, pp. 110–114 (1946). DOI: 10.2307/3002019

---

## CHECKLIST FINAL ANTES DE PASAR AL WORD

- [ ] **[PLACEHOLDER]** Rellenar datos de autoría (nombre, afiliación, correo, ORCID)
- [ ] **[PLACEHOLDER]** Insertar Fig. 1 — Diagrama de arquitectura (ya disponible)
- [ ] **[PLACEHOLDER]** Generar e insertar Fig. 2 — Gráfico de líneas temporales
- [ ] **[PLACEHOLDER]** Generar e insertar Fig. 3 — Box Plot comparativo
- [ ] **[PLACEHOLDER]** Generar e insertar Fig. 4 — Histograma de frecuencias
- [ ] **[PLACEHOLDER]** Generar e insertar Fig. 5 — Curva CDF
- [ ] **[PLACEHOLDER]** Generar e insertar Fig. 6 — Barras agrupadas por percentil
- [ ] **[PLACEHOLDER]** Tomar e insertar Fig. 7 — Captura servidor Linux
- [ ] **[PLACEHOLDER]** Tomar e insertar Fig. 8 — Captura consola Windows
- [ ] Verificar que todas las figuras y tablas están citadas en el texto
- [ ] Verificar legibilidad de todas las figuras en escala de grises
- [ ] Verificar que ninguna tabla está insertada como imagen
- [ ] Los Algoritmos 1, 2 y 3 deben estar en Courier 9pt en Word
- [ ] El texto principal en Times 10pt, justificado, sin negritas en párrafos normales (usar cursiva para énfasis)
- [ ] El resumen debe tener entre 150 y 250 palabras (verificar conteo final)
- [ ] El PDF final NO debe tener números de página
- [ ] Insertar el enlace al repositorio público en el cuerpo del artículo (en Metodología, sección 4.5 o al final)
- [ ] Extensión total: 12 a 15 páginas incluyendo figuras, tablas y referencias
