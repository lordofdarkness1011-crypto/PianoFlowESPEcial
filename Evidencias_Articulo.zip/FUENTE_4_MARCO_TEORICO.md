# FUENTE 4: MARCO TEÓRICO Y CONCEPTOS CLAVE

## Descripción
Conceptos técnicos fundamentales que deben explicarse en las secciones de Introducción y Trabajos Relacionados. Cada concepto incluye su definición técnica precisa y el fenómeno que explica en el contexto del experimento.

---

## 1. WebSocket (Protocolo)
- **Definición formal:** Protocolo de comunicación definido en RFC 6455 (IETF, 2011) que proporciona un canal de comunicación full-duplex bidireccional sobre una única conexión TCP persistente.
- **Mecanismo:** Comienza con un HTTP Upgrade handshake. Una vez establecida, la conexión permanece abierta indefinidamente, permitiendo que servidor y cliente intercambien tramas (frames) sin re-establecer la conexión.
- **Overhead mínimo:** Una vez establecida la conexión, cada mensaje añade solo 2–14 bytes de cabecera (frente a los ~800 bytes de cabeceras HTTP típicas).
- **Relevancia en el artículo:** Es el protocolo propuesto (Escenario B) para transmitir eventos MIDI del Módulo Sala de Conciertos de PianoFlows.

## 2. HTTP REST (Protocolo)
- **Definición formal:** Paradigma arquitectónico definido por Fielding (2000) basado en HTTP, que opera sobre el modelo solicitud-respuesta (request-response). Es inherentemente Stateless (sin estado).
- **Mecanismo de transmisión de datos en tiempo real:** Para aproximarse a la comunicación en tiempo real, HTTP depende de técnicas de Polling: el cliente envía peticiones periódicas al servidor para verificar si hay datos nuevos.
- **Overhead:** Cada petición HTTP requiere: (1) Establecimiento de conexión TCP (3-way handshake: ~1 RTT), (2) Envío de cabeceras HTTP (~400–800 bytes), (3) Cierre o reutilización de la conexión (keep-alive).
- **Relevancia en el artículo:** Es el protocolo de control (Escenario A) con el que se compara WebSocket.

## 3. Round Trip Time (RTT) / Latencia
- **Definición:** Tiempo total transcurrido desde que el cliente envía un paquete hasta que recibe la respuesta del servidor. En el experimento se midió como: `RTT = Date.now()_al_recibir_respuesta - Date.now()_al_enviar_peticion`.
- **Umbrales para juegos musicales (según literatura):**
  - < 20 ms: Indistinguible del juego local
  - 20–50 ms: Óptimo para juegos de ritmo
  - 50–100 ms: Tolerable, inicio de degradación perceptible
  - > 100 ms: Degradación severa de la experiencia
  - > 500 ms: Inaceptable, la música pierde sincronización completamente

## 4. TCP Head-of-Line (HOL) Blocking
- **Definición:** Fenómeno de red que ocurre cuando TCP, al ser un protocolo de entrega ordenada y confiable, detiene la entrega de todos los paquetes subsiguientes en la cola de recepción hasta que un paquete perdido o retrasado es retransmitido y recibido.
- **Impacto en WebSocket:** Al operar sobre un único túnel TCP, un evento de pérdida de paquetes (como el 1% simulado con Clumsy) provoca que todos los mensajes MIDI pendientes en la cola sean bloqueados hasta completar la retransmisión. Esto explica por qué la latencia media de WebSocket (176ms) fue mayor al promedio de HTTP (142ms) en el experimento.
- **Impacto en HTTP:** HTTP abre múltiples conexiones TCP independientes (keep-alive pool). Si un paquete se pierde en una conexión, solo esa petición sufre el bloqueo; las demás continúan. Esto explica la latencia media más baja de HTTP.
- **Por qué HTTP es peor para música:** Aunque el promedio de HTTP es menor, la pérdida de una petición completa implica volver a ejecutar todo el overhead del handshake, generando picos de latencia de hasta 1,318ms (vs 580ms de WebSocket). Estos picos son los que destruyen la experiencia musical.

## 5. Jitter (Variabilidad de Latencia)
- **Definición:** Variación en el retardo de los paquetes transmitidos. Un Jitter alto significa que la latencia es impredecible (a veces llega en 104ms, a veces en 1,318ms).
- **Medida estadística:** La varianza obtenida en el experimento refleja el Jitter: HTTP (varianza: 4,420) vs WebSocket (varianza: 3,861).
- **Relevancia:** Para aplicaciones musicales, un Jitter bajo (WebSocket) es más importante que una latencia media baja (HTTP), porque garantiza una sincronización estable.

## 6. Prueba de Welch (T-Test para varianzas desiguales)
- **Cuándo se usa:** Cuando se comparan dos grupos con varianzas estadísticamente distintas (en el experimento: 4,420 vs 3,861). La Prueba T de Student clásica asume varianzas iguales; la variante de Welch corrige los grados de libertad para hacer válida la comparación.
- **Cómo interpretar p < 0.0001:** La probabilidad de que la diferencia observada entre HTTP y WebSocket sea puro azar es menor al 0.01%. La diferencia es estadísticamente real y reproducible.

## 7. Fase de Calentamiento (JIT Warm-up)
- **Problema:** Los primeros mensajes en Node.js son más lentos porque el motor V8 compila el código JavaScript en tiempo real (Just-In-Time Compilation). Las primeras peticiones no son representativas del rendimiento en estado estable.
- **Solución aplicada:** Se descartaron las primeras 100 iteraciones (10% de N=1,000) de cada cliente, analizando únicamente las 900 restantes por cliente (3,600 en total con 4 clientes) en estado estable.

## 8. Clumsy (Emulación de Red / Network Impairment)
- **Naturaleza:** Software de emulación de red para Windows que intercepta paquetes a nivel de driver y aplica artificialmente condiciones adversas (latencia, pérdida, corrupción).
- **Framing correcto en el artículo:** No debe presentarse como simulación de una red 4G específica. PianoFlows está diseñado para operar sobre WiFi/LAN. Sin embargo, las redes WiFi domésticas presentan condiciones impredecibles: interferencias electromagnéticas, saturación del router, retransmisiones TCP, búfer de colas y pérdida de paquetes esporádica. La inyección de 50ms y 1% packet loss representa un **Análisis de Caso Extremo (Worst-Case Scenario)** reproducible y controlado, que expone las diferencias de resiliencia de los protocolos que en una LAN ideal permanecerían ocultas.
- **Justificación científica:** En el diseño experimental, probar exclusivamente en condiciones ideales (LAN sin pérdidas) solo valida el funcionamiento nominal, no la robustez ante fallos. La metodología de estresar el sistema bajo condiciones adversas controladas es estándar en investigación de redes (análoga al uso de `tc netem` en Linux) y permite identificar los límites de cada protocolo antes de que fallen en producción real.
