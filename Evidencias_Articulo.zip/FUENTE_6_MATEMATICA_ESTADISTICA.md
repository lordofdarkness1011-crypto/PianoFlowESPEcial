# FUENTE 6: FUNDAMENTOS MATEMÁTICOS Y ESTADÍSTICOS

## Descripción
Todos los cálculos matemáticos con fórmulas explícitas, valores intermedios y citas de fuentes. Esta información sustenta la sección de Resultados del artículo. Ninguna afirmación estadística queda sin respaldo.

---

## 1. Justificación de la elección de la Prueba de Welch (no T-Test clásica)

**¿Por qué Welch y no Student?**
La Prueba T de Student clásica asume que las varianzas de ambos grupos son iguales (*homocedasticidad*). En este experimento las varianzas son diferentes:
- Varianza HTTP: **s²₂ = 3,590.65 ms²**
- Varianza WebSocket: **s²₁ = 3,975.87 ms²**

Cuando las varianzas son distintas, el estadístico T de Student produce intervalos de confianza incorrectos. La corrección de Welch (1947) ajusta los grados de libertad para compensar esta diferencia.

> **Fuente para citar:** Welch, B.L.: The generalization of Student's problem when several different population variances are involved. *Biometrika*, Vol. 34, No. 1-2, pp. 28–35 (1947). DOI: 10.1093/biomet/34.1-2.28

---

## 2. Estadísticas Descriptivas Completas (Estado Estable STEADY)

### Tabla de estadísticas descriptivas

| Estadístico           | HTTP REST   | WebSocket   |
|-----------------------|------------:|------------:|
| **N** (muestras)      | 3,600       | 3,600       |
| **Media (x̄)**        | 142.13 ms   | 176.35 ms   |
| **Desv. Estándar (s)**| 59.92 ms    | 63.05 ms    |
| **Varianza (s²)**     | 3,590.65    | 3,975.87    |
| **Mínimo**            | 104 ms      | 104 ms      |
| **Q1 (P25)**          | 123 ms      | 140 ms      |
| **Mediana (P50)**     | 129 ms      | 164 ms      |
| **Q3 (P75)**          | 143 ms      | 169 ms      |
| **Máximo**            | 1,318 ms    | 580 ms      |
| **IQR (Q3 − Q1)**     | 20 ms       | 29 ms       |
| **Cerca sup. (Q3+1.5·IQR)** | 173 ms | 212.5 ms  |
| **Valores atípicos**  | 105         | 433         |

> **Fuente para citar estadísticas descriptivas:** Triola, M.F.: *Elementary Statistics*, 13th ed. Pearson Education (2018). ISBN: 978-0-13-446242-8

---

## 3. Estadísticas de Box Plot (Para la Figura de Distribución)

Los valores del Box Plot se calcularon usando el método de Tukey (1977) con cercas a 1.5×IQR.

### HTTP REST
- Límite inferior de cerca: Q1 − 1.5×IQR = 123 − 1.5×20 = **93 ms**
- Límite superior de cerca: Q3 + 1.5×IQR = 143 + 1.5×20 = **173 ms**
- **105 valores atípicos** (outliers) superiores: desde 174 ms hasta 1,318 ms
- Estos outliers representan el **2.92%** de la muestra total

### WebSocket
- Límite inferior de cerca: Q1 − 1.5×IQR = 140 − 1.5×29 = **96.5 ms**
- Límite superior de cerca: Q3 + 1.5×IQR = 169 + 1.5×29 = **212.5 ms**
- **433 valores atípicos** (outliers) superiores: desde 213 ms hasta 580 ms
- Estos outliers representan el **12.03%** de la muestra total

> **Interpretación para el artículo:** La mayor cantidad de outliers en WebSocket refleja el efecto del TCP Head-of-Line Blocking bajo pérdida de paquetes (1%). Sin embargo, los outliers de HTTP alcanzan valores 2.27× más extremos (1,318 ms vs 580 ms), siendo estos los que resultan fatales para la sincronización musical.

> **Fuente para citar el método de Box Plot:** Tukey, J.W.: *Exploratory Data Analysis*. Addison-Wesley (1977). ISBN: 978-0-201-07616-5

---

## 4. Prueba T de Welch — Desarrollo Matemático Completo

### Datos de entrada
- Grupo 1 (WebSocket): n₁ = 3,600 | x̄₁ = 176.3481 ms | s²₁ = 3,975.8735 ms²
- Grupo 2 (HTTP REST): n₂ = 3,600 | x̄₂ = 142.1342 ms | s²₂ = 3,590.6463 ms²

### Fórmula del Estadístico T de Welch

```
        (x̄₁ − x̄₂)
t = ─────────────────────────
    √(s²₁/n₁  +  s²₂/n₂)
```

### Desarrollo paso a paso

**Paso 1 — Error estándar de cada grupo:**
```
s²₁/n₁ = 3,975.8735 / 3,600 = 1.104409
s²₂/n₂ = 3,590.6463 / 3,600 = 0.997402
```

**Paso 2 — Error estándar combinado (SE):**
```
SE = √(1.104409 + 0.997402)
SE = √(2.101811)
SE = 1.449762 ms
```

**Paso 3 — Estadístico T:**
```
t = (176.3481 − 142.1342) / 1.449762
t = 34.2139 / 1.449762
t = 23.5997
```

### Fórmula de Grados de Libertad (Ecuación de Welch-Satterthwaite)

```
         (s²₁/n₁  +  s²₂/n₂)²
df = ─────────────────────────────────────
     (s²₁/n₁)²/(n₁−1)  +  (s²₂/n₂)²/(n₂−1)
```

### Desarrollo paso a paso (df)

**Numerador:**
```
(1.104409 + 0.997402)² = (2.101811)² = 4.417602
```

**Denominador:**
```
(1.104409)² / (3,600−1)  +  (0.997402)² / (3,600−1)
= 1.219719 / 3,599  +  0.994810 / 3,599
= 0.000339  +  0.000276
= 0.000615
```

**Grados de libertad:**
```
df = 4.417602 / 0.000615 = 7,179.39 ≈ 7,179
```

> **Fuente para la ecuación de Welch-Satterthwaite:** Satterthwaite, F.E.: An Approximate Distribution of Estimates of Variance Components. *Biometrics Bulletin*, Vol. 2, No. 6, pp. 110–114 (1946). DOI: 10.2307/3002019

### Decisión estadística

Con t = 23.5997 y df = 7,179:
- Valor crítico para α = 0.05 (bilateral): t_crítico ≈ 1.960
- 23.5997 >> 1.960 → **Se rechaza H₀**
- p-value calculado: **p < 0.0001**

> **Fuente para el nivel de significancia α = 0.05:** Field, A.: *Discovering Statistics Using IBM SPSS Statistics*, 5th ed. SAGE Publications (2018). ISBN: 978-1-5264-1952-1. (Establece α = 0.05 como umbral estándar en ciencias aplicadas.)

> **Nota sobre el p-value:** El valor p no se calcula manualmente; se obtiene de la distribución T acumulada con df=7,179. Para df > 120, la distribución T converge a la distribución normal estándar Z. Con T = 23.60 y distribución Z, P(Z > 23.60) ≈ 10⁻¹²², efectivamente 0 para cualquier propósito práctico, justificando p < 0.0001.

---

## 5. Referencias adicionales para esta sección matemática

Agregar a la lista de referencias del artículo (por usar fórmulas estadísticas):

**[A]** Welch, B.L.: The generalization of Student's problem when several different population variances are involved. *Biometrika*, Vol. 34, No. 1-2, pp. 28–35 (1947). DOI: 10.1093/biomet/34.1-2.28

**[B]** Satterthwaite, F.E.: An Approximate Distribution of Estimates of Variance Components. *Biometrics Bulletin*, Vol. 2, No. 6, pp. 110–114 (1946). DOI: 10.2307/3002019

**[C]** Tukey, J.W.: *Exploratory Data Analysis*. Addison-Wesley (1977). ISBN: 978-0-201-07616-5

> **Nota:** Si el artículo tiene espacio para 12-15 referencias en total, evalúa incluir [A] Welch (1947) y [B] Satterthwaite (1946) en la lista oficial, ya que respaldan directamente los cálculos estadísticos del experimento. [C] Tukey puede citarse en el pie de figura del Box Plot.
