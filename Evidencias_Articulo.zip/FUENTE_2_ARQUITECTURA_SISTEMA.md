# FUENTE 2: ARQUITECTURA DEL SISTEMA (PIANOFLOWS)

## Descripción
Documentación técnica exhaustiva del sistema PianoFlows. Esta información debe usarse en la sección "Arquitectura de la Solución" / "Caso de Estudio" del artículo.

---

## Stack Tecnológico

### Frontend
- **Framework:** React 18 (SPA - Single Page Application)
- **Motor de Audio:** Tone.js — usa `Tone.now()` para garantizar tiempos de audio independientes del Garbage Collector de JavaScript
- **Captura MIDI:** Web MIDI API nativa del navegador (W3C Standard)
- **Comunicación en tiempo real:** Socket.io Client (v4)
- **Despliegue:** Netlify (CDN global)

### Backend
- **Entorno:** Node.js con framework Express.js
- **Servidor de WebSockets:** Socket.io (v4.8.3)
- **Base de datos:** PostgreSQL Serverless (Neon.tech)
- **Almacenamiento multimedia:** Cloudinary (CDN de activos estáticos)
- **Autenticación:** JSON Web Tokens (JWT) — modelo Stateless
- **Notificaciones / Emails transaccionales:** Resend API
- **Despliegue:** Render.com (contenedor Linux)
- **Logs:** Winston

### Módulo Evaluado (Módulo Sala de Conciertos — Multijugador)
El componente evaluado en el experimento es exclusivamente el módulo de salas multijugador:

**Archivo clave del servidor:** `backend/controllers/socketController.js`
**Archivo clave del cliente:** `frontend/src/components/VersusEngine.jsx`

**Flujo de un evento musical en Módulo Sala de Conciertos (WebSocket):**
1. El usuario presiona una tecla del piano físico conectado por MIDI USB.
2. La Web MIDI API del navegador dispara un evento `midimessage` en el Frontend (React).
3. El componente `VersusEngine.jsx` captura el evento y ejecuta `socket.emit('play_note', { note, velocity, instrument })`.
4. Socket.io encapsula el mensaje y lo envía por el túnel TCP persistente hacia el servidor Node.js.
5. El servidor ejecuta `socket.to(roomId).emit('user_played_note', data)` para hacer broadcast a todos los jugadores de la sala.
6. El cliente receptor reproduce la nota en su motor de audio local (Tone.js).

**Flujo de un evento musical hipotético usando HTTP REST (Escenario A del experimento):**
1. El usuario presiona la tecla → el Frontend ejecuta `axios.post('/api/test/note', data)`.
2. El cliente abre una nueva conexión TCP, ejecuta el handshake TCP (3-way), negocia cabeceras HTTP y envía el body JSON.
3. El servidor responde. El cliente cierra la conexión.
4. Para cada nota musical se repite todo el proceso desde cero.

---

## Capacidad del Sistema (Contexto del Experimento)
- Máximo de jugadores por sala: 4
- Eventos MIDI por jugador por segundo (estimado en uso real): 10–15 (notas simples) hasta 25+ (acordes y arpegios)
- Carga máxima esperada en una sala llena: 4 jugadores × 25 eventos/seg = **100 eventos/seg**
- Esta cifra fue la usada para diseñar la carga del experimento

---

## Endpoints Relevantes del Backend
| Método | Ruta                 | Descripción                                        |
|--------|----------------------|----------------------------------------------------|
| POST   | `/api/test/note`     | Endpoint creado para el experimento. Recibe una nota y retorna `serverTime`, `cpuLoad` y `ramMB`. |
| WS     | `test_latencia_ws`   | Evento WebSocket creado para el experimento. El servidor hace echo del payload con métricas de hardware. |
| WS     | `play_note`          | Evento productivo de la app. Hace broadcast a la sala. |
| WS     | `create_room`        | Crea una sala multijugador. |
| WS     | `join_room`          | Un jugador se une a una sala. |

---

## Infraestructura del Experimento
- **Equipo Servidor (Nodo A):** Laptop con POP! OS Linux, Intel Core i7-8750H, 24 GB RAM DDR4
- **Equipo Cliente (Nodo B):** PC de Escritorio con Windows 11, AMD Ryzen 5 5600G, 16 GB RAM DDR4 3200MHz
- **Tipo de Red:** LAN WiFi 802.11ac (misma subred privada)
- **Puertos implicados:** TCP 3000 (servidor Node.js)
- **Emulador de red:** Clumsy (Windows), filtro `tcp.DstPort == 3000 or tcp.SrcPort == 3000`
