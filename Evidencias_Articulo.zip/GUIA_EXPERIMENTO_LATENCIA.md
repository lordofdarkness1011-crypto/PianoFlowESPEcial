# Guía de Ejecución: Experimento de Latencia (Planteamiento 1)

Has elegido el **Planteamiento 1**: *Evaluación de latencia en la transmisión bidireccional de eventos MIDI empleando WebSockets frente a HTTP Polling en motores musicales web.*

Para cumplir estrictamente con los requisitos del archivo `instruccionesarticulo.txt`, deberás transformar tu aplicación en un laboratorio de pruebas. A continuación, te detallo paso a paso la metodología que debes aplicar y cómo estructurar el artículo en la plantilla Springer.

---

## FASE 1: Definición del Experimento (Metodología)

Según tu rúbrica, debes tener escenarios, variables y métricas claras para que el experimento sea "reproducible".

* **Componente evaluado:** El sistema de transmisión de notas musicales en tiempo real del Módulo Sala de Conciertos.
* **Escenario A (Control/Tradicional):** Transmitir eventos musicales mediante peticiones HTTP `POST` convencionales (REST).
* **Escenario B (Propuesto/PianoFlows):** Transmitir los mismos eventos mediante WebSockets persistentes (`Socket.io`).
* **Variables:**
  * **Independiente:** El protocolo de red utilizado (HTTP vs WebSocket).
  * **Dependientes (Métricas):** 
    1. Tiempo de Ida y Vuelta o RTT (Latencia en milisegundos).
    2. Rendimiento (Número de mensajes entregados exitosamente por segundo).
  * **Controladas:** El tamaño del *Payload* JSON (ej. `{"midi": 60, "velocity": 80, "timestamp": 12345}`), la distancia física al servidor, y el número de clientes concurrentes simulados.

---

## FASE 2: Ejecución de las Pruebas (El Código)

El profesor exige que el resultado no sea "inventado" y que se usen herramientas comprobables. No necesitas modificar tu código de producción; puedes crear un script independiente en la carpeta del proyecto para estresar el servidor localmente o en la nube.

**Paso a paso recomendado:**
1. **Crear el endpoint REST de prueba:** En tu backend (`api.js` o `versusController.js`), crea un endpoint temporal `POST /api/test/note` que reciba una nota y devuelva `{ success: true, timestamp_recibido: Date.now() }`. Esto simulará el Escenario A.
2. **Aprovechar los WebSockets existentes:** El Escenario B ya lo tienes construido con `socket.emit('play_note_versus', data)`.
3. **El Script de Pruebas:** Crea un archivo llamado `latencia_test.js` en tu PC. Usa librerías como `axios` (para probar REST) y `socket.io-client` (para probar WebSockets).
4. **La Ejecución:** En tu script, programa un bucle que simule a 5 jugadores tocando 10 notas por segundo (50 peticiones/segundo). 
5. **Recolección:** Para cada protocolo (REST y WebSockets), resta el tiempo de envío original menos el tiempo en que el servidor o el cliente acusó recibo de la nota. Guarda estos tiempos en un archivo Excel (`.csv`).

---

## FASE 3: Redacción del Artículo en la Plantilla Springer

Con los datos en tu Excel, deberás redactar el informe (12 a 15 páginas). Aquí te indico qué poner en cada sección exigida:

### 1. Título
*Evaluación de la latencia en la transmisión de eventos musicales MIDI: WebSockets frente a HTTP en aplicaciones distribuidas.*

### 2. Resumen (Abstract)
Debe ser directo (150-250 palabras). *Ejemplo de redacción:* "Este artículo evalúa el impacto del protocolo de comunicación en la latencia de un motor musical distribuido. Se desarrolló una prueba de concepto (PianoFlows) para comparar la transmisión de eventos MIDI mediante HTTP y WebSockets. Los resultados demostraron que WebSockets reduce la latencia en un X% (poner dato real) y mantiene un tiempo de respuesta estable de Y ms frente a alta concurrencia, comprobando que arquitecturas asíncronas persistentes son críticas para evitar la desincronización en aplicaciones de Cloud Gaming."

### 3. Introducción
Explica el problema: En juegos de ritmo (Guitar Hero, Osu!, PianoFlows) un retraso de 100ms es inaceptable porque la música pierde el ritmo (desincronización). Menciona que HTTP, al ser *stateless* y requerir un "Handshake" por cada conexión, añade un overhead perjudicial. Tu pregunta de investigación es: *¿Cómo influye el uso de una conexión persistente (WebSockets) frente a peticiones transaccionales (HTTP) en la latencia de sincronización musical en un entorno web distribuido?*

### 4. Trabajos Relacionados
Busca en Google Scholar o IEEE Xplore 10 artículos de los últimos 6 años usando estos términos:
* *"Latency in Cloud Gaming"*
* *"WebSocket vs REST performance evaluation"*
* *"Web MIDI API network latency"*
Extrae sus DOIs y compara cómo ellos abordaron el problema. (Ej: "A diferencia del autor X que midió latencia en chats de texto, este estudio evalúa paquetes MIDI de alta frecuencia").

### 5. Arquitectura de la Solución
Incluye el diagrama de arquitectura de PianoFlows, pero **concéntrate solo en el flujo de los WebSockets**. Explica cómo el Frontend captura el evento del piano físico con la Web MIDI API y lo dispara por Socket.io hacia el Backend en Node.js, y cómo este hace el *Broadcast* a la sala en milisegundos.

### 6. Metodología
Describe el escenario de pruebas (FASE 1 y FASE 2 de esta guía). Menciona el hardware que usaste para la prueba (procesador, RAM), si el servidor estaba en localhost o en Render, y que ejecutaste la prueba 1,000 veces por cada escenario para tener rigor estadístico.

### 7. Resultados
¡Esta es la parte más importante!
* Crea un gráfico de líneas donde el eje X sea el número de petición (1 al 1000) y el eje Y sea la latencia en milisegundos. 
* Crea una tabla comparativa con la **Latencia Media**, **Latencia Máxima** y **Varianza** de HTTP vs WebSockets.
* Adjunta un fragmento de código de tu script de prueba o capturas de pantalla de la terminal mostrando la ejecución.

### 8. Discusión
Analiza por qué WebSockets ganó (seguramente arrasará en las pruebas). Explica el "TCP Handshake overhead" de HTTP, el costo de armar cabeceras en cada petición y cómo los WebSockets mantienen el tubo abierto ahorrando recursos computacionales. Argumenta las amenazas a la validez (ej. "La prueba se hizo en local, en un entorno de nube real con mala conexión 4G la diferencia sería aún más abismal").

### 9. Conclusiones
Responde a tu pregunta de investigación confirmando que HTTP es inviable para motores musicales en tiempo real y que WebSockets es el estándar necesario. Como trabajo futuro, sugiere evaluar protocolos basados en UDP como WebRTC para audio directo.

---

### ¿Cómo procedemos?
¿Quieres que yo te programe el script automático (`latencia_test.js`) en Node.js para que tú solo lo corras en tu consola y te imprima los datos exactos que necesitas meter a las gráficas y tablas?

---

## FASE 4: Reglas de Formato Oficiales (Basado en PrototipoSpringer.doc)

He revisado tu archivo `PrototipoSpringer.doc`. Al momento de pasar toda tu investigación a Microsoft Word (u OpenOffice), **es crítico que respetes estas reglas tipográficas estrictas**, ya que el comité revisor rechazará tu artículo si no cumple este formato exacto:

* **Márgenes y Área de Impresión:** 122 mm × 193 mm, con texto justificado.
* **Fuentes y Tamaños:** 
  * Título del Artículo: Times 14 puntos (Centrado, negrita).
  * Títulos principales (Ej. 1 Introducción): Times 12 puntos (Negrita).
  * Subtítulos (Ej. 1.1 Metodología): Times 10 puntos (Negrita).
  * Texto normal: Times 10 puntos, interlineado sencillo.
  * Resumen y Datos de contacto: Times 9 puntos.
* **Referencias:** Deben citarse usando corchetes numéricos en orden de aparición en el texto (ej. `[1]`, `[2]`). Al final del documento, estructurarlas según el patrón: `Autores: Título. Editorial/Revista, Vol, pp. (Año)`.
* **Gráficos de Latencia (Crucial para nosotros):** El profesor exige figuras legibles con alta resolución (mínimo 800 dpi, recomendado 1200 dpi). Así que cuando generemos el gráfico de nuestros resultados, debes exportarlo en formato vectorial (PDF/SVG) o PNG de altísima resolución. El texto "Fig 1. ..." va debajo del gráfico.
* **Código Fuente (Opcional):** Si pegas un trozo del código de nuestro experimento, usa fuente Courier de 9 puntos.
