# FUENTE 7: EVIDENCIAS VISUALES (FIGURAS, TABLAS, ALGORITMOS)

## Descripción
Lista exhaustiva de todas las figuras, tablas y bloques de código que debe contener el artículo, con el contenido exacto de cada una y los datos listos para construirlas. Ninguna de estas evidencias se inventa; todas provienen de los datos del experimento o del código fuente del sistema.

---

## TABLAS (Título encima, formato editable, no captura de pantalla)

### Tabla 1. Estadísticas descriptivas de latencia (RTT) por protocolo — Fase STEADY (N=3,600)

| Estadístico         | HTTP REST | WebSocket (Socket.io) |
|---------------------|----------:|----------------------:|
| Media (x̄)          | 142.13 ms | 176.35 ms             |
| Desviación estándar | 59.92 ms  | 63.05 ms              |
| Varianza (s²)       | 3,590.65  | 3,975.87              |
| Mínimo              | 104 ms    | 104 ms                |
| Q1 (Percentil 25)   | 123 ms    | 140 ms                |
| Mediana (P50)       | 129 ms    | 164 ms                |
| Q3 (Percentil 75)   | 143 ms    | 169 ms                |
| P90                 | 165 ms    | 248 ms                |
| P99                 | 473 ms    | 450 ms                |
| **Máximo (Lag Spike)** | **1,318 ms** | **580 ms**       |
| IQR                 | 20 ms     | 29 ms                 |
| Valores atípicos    | 105 (2.92%) | 433 (12.03%)        |

### Tabla 2. Consumo de recursos del servidor Node.js durante el experimento

| Métrica                 | HTTP REST | WebSocket (Socket.io) | Diferencia |
|-------------------------|----------:|----------------------:|----------:|
| CPU Load Avg (1 min)    | 1.607     | 1.612                 | +0.31%    |
| RAM Heap (MB)           | 21.76 MB  | 22.29 MB              | +2.44%    |

### Tabla 3. Resultados de la Prueba T de Welch

| Parámetro                         | Valor        |
|-----------------------------------|-------------:|
| Diferencia de medias (x̄₁ − x̄₂) | 34.21 ms     |
| Error estándar (SE)               | 1.4498       |
| **Estadístico T**                 | 23.5997      |
| **Grados de libertad (df)**       | 7,179        |
| Valor p                           | < 0.0001     |
| Nivel de significancia (α)        | 0.05         |
| Decisión                          | Se rechaza H₀ |

### Tabla 4. Configuración del entorno de experimentación

| Parámetro               | Valor                                    |
|-------------------------|------------------------------------------|
| Servidor (Nodo A)       | Intel Core i7-8750H, 24 GB RAM, POP! OS  |
| Cliente (Nodo B)        | AMD Ryzen 5 5600G, 16 GB RAM, Windows 11 |
| Red                     | LAN WiFi 802.11ac                        |
| Emulación de red        | Clumsy 0.3 — Lag 50ms + Drop 1%         |
| Protocolo A (Control)   | HTTP REST — POST /api/test/note          |
| Protocolo B (Propuesto) | WebSocket — evento test_latencia_ws      |
| Clientes concurrentes   | 4                                        |
| Iteraciones por cliente | 1,000                                    |
| Fase de calentamiento   | 100 iteraciones descartadas por cliente  |
| Muestras válidas (N)    | 3,600 por protocolo                      |
| Frecuencia de carga     | 25 eventos/seg/cliente (100 total/seg)   |

---

## FIGURAS Y SU JUSTIFICACIÓN CIENTÍFICA

### ¿Por qué se necesitan múltiples tipos de gráficos?
Cada tipo de gráfico responde a una pregunta científica distinta sobre los mismos datos. Un solo gráfico no es suficiente para describir completamente el comportamiento de un sistema distribuido en tiempo real.

| Figura | Tipo de gráfico | Pregunta que responde |
|---|---|---|
| Fig. 2 | Líneas (Series temporal) | ¿Cómo se comporta la latencia **en el tiempo** en cada protocolo? |
| Fig. 3 | Box Plot | ¿Cómo es la **distribución estadística** de las latencias? |
| Fig. 4 | Histograma de frecuencias | ¿Cuál es la **forma de la distribución** (sesgo, cola larga)? |
| Fig. 5 | CDF (Función de Distribución Acumulada) | ¿Qué **porcentaje de peticiones** se sirven por debajo de X ms? |
| Fig. 6 | Barras agrupadas por percentil | ¿Cómo cambia la **brecha entre protocolos** según el percentil? |
| Fig. 7 | Capturas de pantalla | **Evidencia** de que las pruebas fueron ejecutadas realmente |

---

### Fig. 1. Diagrama de arquitectura del sistema PianoFlows.
*[Usuario ya tiene esta imagen disponible en formato vectorial.]*

---

### Fig. 2. Gráfico de líneas — Latencia por iteración (Serie temporal)
**¿Para qué sirve?** Muestra el comportamiento de la latencia a lo largo del tiempo de la prueba. Permite ver los picos (Lag Spikes) en el momento exacto en que ocurrieron.

**Cómo construirlo (Excel o Google Sheets):**
- Fuente de datos: `resultados_latencia_http.csv` y `resultados_latencia_ws.csv`
- Filtrar solo filas con Fase=STEADY
- Eje X: Columna `Iteracion` (1 a ~1000, solo iteraciones del ClienteID=1 para no saturar)
- Eje Y: Columna `Latencia_ms`
- Dos series en el mismo gráfico: una roja (HTTP) y una azul (WebSocket)
- Añadir línea horizontal punteada en Y=50ms: etiqueta "Umbral crítico [7]"
- Escalar eje Y hasta 1,400 ms
- Epígrafe: *"Fig. 2. Evolución temporal de la latencia (RTT) por iteración para HTTP REST y WebSocket bajo condiciones de red adversas emuladas (50 ms lag + 1% packet loss). Se observan picos máximos de 1,318 ms en HTTP y 580 ms en WebSocket."*

---

### Fig. 3. Box Plot — Distribución estadística de latencias
**¿Para qué sirve?** Muestra la distribución completa de los datos (mediana, cuartiles, outliers). Es el gráfico estándar en artículos de sistemas para comparar distribuciones entre dos grupos.

**Valores exactos (calculados de los CSV):**

| Estadístico     | HTTP REST | WebSocket |
|-----------------|----------:|----------:|
| Mínimo          | 104 ms    | 104 ms    |
| Q1 (P25)        | 123 ms    | 140 ms    |
| Mediana (P50)   | 129 ms    | 164 ms    |
| Q3 (P75)        | 143 ms    | 169 ms    |
| Cerca superior (Q3+1.5×IQR) | 173 ms | 212.5 ms |
| Outliers hasta  | 1,318 ms  | 580 ms    |
| N outliers      | 105       | 433       |

- Mostrar ambos box plots lado a lado en el mismo gráfico
- Eje Y: hasta 1,400 ms
- Marcar con punto rojo el valor máximo de cada protocolo
- Epígrafe: *"Fig. 3. Box Plot comparativo de la distribución de latencias (RTT). Los valores atípicos superiores de HTTP REST alcanzan 1,318 ms frente a los 580 ms de WebSocket, evidenciando mayor resiliencia del protocolo de conexión persistente."*

---

### Fig. 4. Histograma de frecuencias — Distribución por rangos de latencia
**¿Para qué sirve?** Muestra la **forma** de la distribución: si es simétrica, sesgada a la derecha (cola larga), o tiene múltiples modas. Para este experimento es especialmente revelador porque HTTP tiene una cola derecha muy pronunciada.

**Datos calculados (N=3,600 por protocolo):**

| Rango de latencia | HTTP (N) | HTTP (%) | WebSocket (N) | WebSocket (%) |
|---|---:|---:|---:|---:|
| 100–150 ms | 3,021 | 83.92% | 1,033 | 28.69% |
| 150–200 ms | 479 | 13.31% | 1,998 | 55.50% |
| 200–250 ms | 2 | 0.06% | 214 | 5.94% |
| 250–300 ms | 6 | 0.17% | 117 | 3.25% |
| 300–350 ms | 9 | 0.25% | 94 | 2.61% |
| 350–400 ms | 0 | 0.00% | 74 | 2.06% |
| 400–500 ms | 62 | 1.72% | 64 | 1.78% |
| 500–700 ms | 16 | 0.44% | 6 | 0.17% |
| 700–1,000 ms | 4 | 0.11% | 0 | 0.00% |
| 1,000–1,400 ms | 1 | 0.03% | 0 | 0.00% |

**Insight para el texto:** El 83.92% de las peticiones HTTP se sirvieron en menos de 150 ms (explica la media baja), pero el 2.30% restante generó picos devastadores. WebSocket tiene una distribución más dispersa pero sin colas extremas.

- Construir como histograma de barras dobles (dos colores por bin)
- Eje Y: frecuencia relativa (%)
- Escala logarítmica en eje X si se desea visualizar todos los bins
- Epígrafe: *"Fig. 4. Histograma de frecuencias de latencia por protocolo. HTTP REST concentra el 83.92% de sus peticiones bajo 150 ms pero presenta una cola derecha que alcanza los 1,318 ms, característica de la inestabilidad del protocolo ante pérdida de paquetes."*

---

### Fig. 5. CDF — Función de Distribución Acumulada
**¿Para qué sirve?** Es el gráfico **más utilizado en artículos de redes y sistemas** para comparar el rendimiento de protocolos. Responde a: "¿Qué porcentaje de mis usuarios experimenta menos de X ms de latencia?". Es más informativo que la media y más compacto que el histograma.

**Datos calculados (percentiles clave):**

| Percentil | HTTP REST | WebSocket |
|---|---:|---:|
| P50 (Mediana) | 129 ms | 164 ms |
| P75 | 143 ms | 169 ms |
| P90 | 165 ms | 248 ms |
| P95 | 169 ms | 332 ms |
| P99 | 473 ms | 450 ms |
| P99.5 | 505 ms | 460 ms |
| P99.9 | 726 ms | 532 ms |
| P100 (Máximo) | 1,318 ms | 580 ms |

**Insight crítico para el artículo:** Hasta el P99, HTTP parece ligeramente mejor. Pero en el P99.9 HTTP cae a 726 ms frente a los 532 ms de WebSocket. Y en el máximo absoluto, la diferencia es de 738 ms. Esto demuestra que el problema de HTTP no es frecuente, pero cuando ocurre, es catastrófico.

- Eje X: Latencia en ms (escala de 100 a 1,400)
- Eje Y: Probabilidad acumulada (0% a 100%)
- Dos curvas en el mismo gráfico (HTTP roja, WebSocket azul)
- Marcar con línea vertical punteada el umbral de 50 ms y 500 ms
- Epígrafe: *"Fig. 5. Función de Distribución Acumulada (CDF) de latencias. Hasta el percentil 95, HTTP REST presenta menor latencia; sin embargo, en la cola de la distribución (P99.9 y P100), WebSocket demuestra una resiliencia superior al acotar los picos máximos en 532 ms frente a los 726 ms de HTTP."*

---

### Fig. 6. Gráfico de barras agrupadas — Comparativa de percentiles clave
**¿Para qué sirve?** Complementa la CDF con una visualización discreta y fácil de leer en impresión en blanco y negro. Permite que el lector compare directamente los valores de ambos protocolos en los percentiles más relevantes.

**Datos para el gráfico:**

| Métrica  | HTTP REST | WebSocket |
|----------|----------:|----------:|
| Media    | 142 ms    | 176 ms    |
| Mediana  | 129 ms    | 164 ms    |
| P90      | 165 ms    | 248 ms    |
| P99      | 473 ms    | 450 ms    |
| Máximo   | 1,318 ms  | 580 ms    |

- Barras dobles agrupadas por métrica
- Escala en eje Y hasta 1,400 ms
- Tratar de que sea legible en grises (usar tramas, no solo colores)
- Epígrafe: *"Fig. 6. Comparativa de percentiles de latencia entre HTTP REST y WebSocket. La diferencia más significativa se observa en el valor máximo, donde HTTP supera en un 126.9% los picos de WebSocket (1,318 ms vs 580 ms)."*

---

### Fig. 7 y Fig. 8. Capturas de pantalla de ejecución (Evidencias de ejecución real)

**Fig. 7 — Logs del servidor Linux durante la prueba:**
- Captura de la terminal con `npm start` mostrando: los `POST /api/test/note` y las 4 conexiones WebSocket
- Recortar para que muestre solo la información necesaria (ocultar datos sensibles)
- Epígrafe: *"Fig. 7. Registro de actividad del servidor Node.js durante el experimento, mostrando la recepción de peticiones HTTP y el establecimiento de 4 conexiones WebSocket concurrentes."*

**Fig. 8 — Consola del cliente Windows:**
- Captura de `node latencia_test.js` ejecutándose
- Epígrafe: *"Fig. 8. Consola del nodo cliente (Windows 11) ejecutando el script de prueba concurrente."*

---

## ALGORITMOS (Código fuente — Courier 9pt en el artículo)

### Algoritmo 1. Manejador del evento WebSocket de medición de latencia (Servidor — Node.js).

```
socket.on('test_latencia_ws', (data) => {
    socket.emit('test_latencia_ws_response', {
        ...data,
        serverTime : Date.now(),
        cpuLoad    : os.loadavg()[0],
        ramMB      : (process.memoryUsage().heapUsed
                      / 1024 / 1024).toFixed(2)
    });
});
```

### Algoritmo 2. Medición del RTT — HTTP REST (Cliente — Node.js/axios).

```
const start = Date.now();
const response = await axios.post(
    `${SERVER_URL}/api/test/note`, { midi: 60 });
const rtt = Date.now() - start;
fs.appendFileSync(CSV_HTTP,
    `${fase},${clientId},${iter},${rtt},
     ${response.data.cpuLoad},${response.data.ramMB},OK\n`);
```

### Algoritmo 3. Medición del RTT — WebSocket (Cliente — Socket.io-client).

```
// Emisión con timestamp embebido
socket.emit('test_latencia_ws',
    { _testStart: Date.now(), _testIter: enviosIniciados });

// Cálculo al recibir el echo
socket.on('test_latencia_ws_response', (data) => {
    const rtt = Date.now() - data._testStart;
    fs.appendFileSync(CSV_WS,
        `${fase},${clientId},${iter},${rtt},
         ${data.cpuLoad},${data.ramMB},OK\n`);
});
```

---

## CHECKLIST COMPLETO ANTES DE ENTREGAR

### Tablas
- [ ] Tabla 1 — Estadísticas descriptivas completas (editable en Word)
- [ ] Tabla 2 — Consumo de recursos del servidor (editable)
- [ ] Tabla 3 — Resultados de la Prueba T de Welch (editable)
- [ ] Tabla 4 — Configuración del entorno (editable)

### Figuras
- [ ] Fig. 1 — Diagrama de arquitectura (vectorial SVG/PDF — ya disponible)
- [ ] Fig. 2 — Gráfico de líneas temporales (≥800 dpi)
- [ ] Fig. 3 — Box Plot comparativo (≥800 dpi)
- [ ] Fig. 4 — Histograma de frecuencias (≥800 dpi)
- [ ] Fig. 5 — Curva CDF (≥800 dpi)
- [ ] Fig. 6 — Barras agrupadas por percentil (≥800 dpi)
- [ ] Fig. 7 — Captura logs servidor Linux
- [ ] Fig. 8 — Captura consola cliente Windows

### Algoritmos
- [ ] Algoritmo 1 — Evento WS servidor (Courier 9pt)
- [ ] Algoritmo 2 — RTT HTTP cliente (Courier 9pt)
- [ ] Algoritmo 3 — RTT WebSocket cliente (Courier 9pt)

### Verificaciones de formato
- [ ] Todas las figuras tienen epígrafe debajo con "Fig. N." en negrita
- [ ] Todas las tablas tienen título encima con "Tabla N." en negrita
- [ ] Todas las figuras y tablas están citadas en el texto
- [ ] Todas las figuras son legibles en escala de grises
- [ ] Ninguna tabla está insertada como captura de pantalla
- [ ] Los algoritmos están en Courier 9pt precedidos de explicación en 10pt
