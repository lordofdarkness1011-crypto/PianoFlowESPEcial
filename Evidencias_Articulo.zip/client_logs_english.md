```log
C:\Users\RoyaliskLuster\Downloads>npm init -y
Wrote to C:\Users\RoyaliskLuster\Downloads\package.json:

{
  "name": "downloads",
  "version": "1.0.0",
  "description": "",
  "main": "latencia_test.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "keywords": [],
  "author": "",
  "license": "ISC",
  "type": "commonjs"
}

C:\Users\RoyaliskLuster\Downloads>npm install axios socket.io-client

added 34 packages, and audited 35 packages in 3s

6 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities

C:\Users\RoyaliskLuster\Downloads>node latencia_test.js

 STARTING RIGOROUS EXPERIMENT (4 Concurrent Clients)

[1/2] ✎ Hitting server with HTTP REST...
✔ HTTP Test Completed.

[2/2] ✎ Hitting server with WEBSOCKETS...
✔ WebSockets Test Completed.

✎ EXPERIMENT COMPLETE. CSV files ready for T-Test analysis.

C:\Users\RoyaliskLuster\Downloads>
```
