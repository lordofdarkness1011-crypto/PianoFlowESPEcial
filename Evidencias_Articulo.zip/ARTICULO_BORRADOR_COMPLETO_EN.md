# FULL ARTICLE — SPRINGER LNCS DRAFT
# Evaluation of Latency and Resilience in Real-Time MIDI Event Transmission: WebSocket versus HTTP REST in a Distributed Web Music Engine

---

> **USAGE INSTRUCTIONS:**
> This file is the complete draft of the article. The **[PLACEHOLDER: description]** markers indicate sections that the student must complete or verify. Everything else is ready to be transferred to the Word document using the Springer LNCS template.
> The final formatting (fonts, margins, columns) is applied in Word. This file contains the complete and structured content.

---

## Authorship

**[PLACEHOLDER: FIRST AUTHOR]** *(Last name, Student's full name)*
**[PLACEHOLDER: SECOND AUTHOR]** *(Last name, Professor's full name)*

**[PLACEHOLDER: AFFILIATION]**
*(Name of the university, Faculty, Department, City, Country)*
*(Student's institutional e-mail)*
*(Professor's institutional e-mail)*
*(ORCID if available, otherwise use https://orcid.org/0000-000a-bcde-fghi)*

---

## Abstract

PianoFlows is a multiplayer web music engine that allows geographically distributed users to play and share piano notes in real time through the Concert Room Module. In this type of application, musical synchronization imposes stricter latency constraints than conventional messaging or video conferencing applications: variations in response time exceeding 50 ms become perceptible to the user and degrade the gaming experience to an unacceptable level [7]. However, the choice of the communication protocol that best satisfies these constraints under real adverse network conditions has not been empirically evaluated in the context of web music engines. This paper presents a comparative study of the performance of the HTTP REST and WebSocket (via Socket.io) protocols under a high-frequency load of MIDI events, using a controlled and reproducible worst-case scenario (50 ms of additional delay and 1% packet loss emulated with Clumsy). We executed 1,000 iterations per client with 4 concurrent clients, obtaining 3,600 steady-state samples per protocol. The results demonstrate that WebSocket reduced the maximum latency peaks (*Lag Spikes*) by 56% compared to HTTP REST (580 ms versus 1,318 ms), with a statistically significant difference (T = 23.5997; df = 7,179; p < 0.0001). We conclude that WebSocket is the only viable protocol to guarantee bounded latency variability (*jitter*) in distributed music engines.

**Keywords:** WebSocket, HTTP REST, Latency, Jitter, Real-Time, Node.js.

---

## 1 Introduction

The growth of online music entertainment and education platforms has generated a new category of distributed applications that imposes exceptionally strict real-time requirements. Unlike messaging or video conferencing applications, where delays of 100 to 300 ms are generally tolerable, musical synchronization requires sound events between remote participants to arrive within a time window of 50 ms or less for the result to be perceptually coherent [7]. Exceeding this threshold produces auditory desynchronization that the user immediately experiences as rhythmic errors, destroying the collaborative nature of the experience.

PianoFlows is a multiplayer web music engine developed as a distributed application that allows multiple users to play piano notes in real time within shared rooms called Concert Room Module. The system operates on a client-server architecture where the React frontend captures MIDI keyboard events via the Web MIDI API and transmits them to the Node.js backend, which retransmits them to all room participants in real time. This architecture implies that each note pressed by a user must travel the full path to the server and return to the rest of the players before the next note is executed, making the communication protocol the most critical component of the system.

The REST paradigm over HTTP, widely adopted in the development of distributed applications [3], was conceived for transactional request-response interactions. Its stateless communication model requires the establishment of a new TCP connection for each request, with the consequent overhead of HTTP headers of between 400 and 800 bytes per message [4]. Under these conditions, the transmission of 100 MIDI events per second—the characteristic load of a room with four active players—represents a demand that exceeds the protocol's original design. The WebSocket protocol [1], on the other hand, establishes a persistent, bidirectional communication channel over a single TCP connection, reducing the per-message overhead to between 2 and 14 bytes once the connection is established, making it potentially more suitable for this type of load.

However, the choice between these protocols in the specific context of web music engines has not been empirically evaluated with high-frequency MIDI event loads or under reproducible adverse network conditions. Previous studies have focused on comparisons under general messaging loads [5][6] or on analyzing the quality of experience in video cloud gaming platforms [8][9], but they do not address the transmission of high-frequency discrete events with musical constraints.

The main contribution of this work is the empirical evaluation of the impact of network protocol selection on *jitter* in the real-time transmission of MIDI events, demonstrating that maximum latency—and not the mean—is the critical metric for user experience in distributed musical applications.

The research question guiding this study is the following: *how does the network transmission protocol—HTTP REST versus WebSocket—affect the latency and variability (jitter) of MIDI events in a distributed web music application under controlled adverse network conditions?*

The objective of the study is to quantitatively evaluate and compare the performance of HTTP REST and WebSocket under a high-frequency load of MIDI events in the PianoFlows Concert Room Module, measuring mean latency, maximum peaks, and server resource consumption under emulated adverse network conditions.

This article is organized as follows: Section 2 reviews related work; Section 3 describes the architecture of the PianoFlows system; Section 4 details the experimental methodology; Section 5 presents the results; Section 6 discusses the findings; and, finally, Section 7 sets out the conclusions and lines for future work.

---

## 2 Related Work

Real-time communication over the web has evolved from the original request-response model of HTTP towards progressively more efficient bidirectional communication mechanisms. Loreto et al. [2] document the *Long Polling* and *Streaming* techniques as the first attempts to approximate HTTP to real-time communication, identifying their fundamental limitations: added latency due to delayed response emission, resource consumption by artificially kept open connections, and implementation complexity. The WebSocket protocol [1], standardized by the IETF in 2011, was designed specifically to resolve these limitations through a persistent full-duplex communication channel.

Pimentel and Nickerson [5] conducted one of the first empirical studies comparing WebSocket to HTTP *Polling* in real-time data visualization applications, demonstrating significant reductions in latency and network traffic. However, their evaluation was performed under general messaging loads and did not contemplate packet loss. Unlike their work, this study evaluates a specific high-frequency load of MIDI events with four concurrent clients and incorporates packet loss emulation to expose performance under adverse conditions. Bozakov and Susitaival [6] evaluated the performance of the WebSocket protocol under sustained load using continuous message bursts, establishing a testing methodology that this work adopts and extends with the addition of adverse network emulation.

Fielding [3] defines the REST architecture as an architectural style for distributed hypermedia systems, emphasizing the stateless nature of HTTP interactions. This characteristic, although favorable for the horizontal scalability of conventional web services, implies re-establishing a connection on each request, a cost that is disproportionate for high-frequency event applications such as music engines.

In the field of *cloud gaming*, Claypool and Finkel [7] empirically demonstrated that network latency has a quantifiable impact on player performance, with noticeable degradation above 50 ms in action games. Huang et al. [8] presented GamingAnywhere, an open cloud gaming system that analyzes network latency requirements for interactive video streaming. Wang et al. [9] studied the network quality required for *cloud gaming* from the operator's perspective, measuring RTT, *jitter*, and packet loss metrics. The fundamental difference with the present work is that these studies evaluate the underlying network as a black box, while this study evaluates how the application protocol—HTTP versus WebSocket—dampens or amplifies the effect of an imperfect network on musical synchronization events. Soares et al. [11] propose machine learning models to predict the Quality of Experience (QoE) in *cloud gaming* platforms, confirming that latency and *jitter* are the most decisive factors of the user experience in interactive real-time applications.

Murley et al. [10] conducted a large-scale empirical study on the adoption of WebSocket on the modern web, demonstrating its consolidation as a standard mechanism for real-time communication applications. Unlike their conclusions oriented towards adoption trends, this work evaluates the performance under a specific musical load.

Unlike previous works, which evaluated WebSocket under general messaging loads or video streaming environments, this study applies a specific high-frequency load of MIDI events (100 events per second with four concurrent clients), incorporates packet loss emulation to reproduce realistic adverse network conditions, and identifies maximum latency (*jitter*) as the critical metric for musical synchronization, as opposed to the average RTT used in previous studies.

---

## 3 Solution Architecture

PianoFlows is a distributed web application of the SPA (*Single Page Application*) type oriented towards real-time collaborative musical performance. The architecture follows a client-server model with a clear separation of layers.

**[PLACEHOLDER: Fig. 1]**
*Insert here the architecture diagram of the PianoFlows system (already available as an image). Title: "Fig. 1. Architecture diagram of the PianoFlows system."*

### 3.1 System Components

The frontend is implemented in React 18 as an SPA hosted on Netlify (global CDN). The capture of MIDI events is done through the browser's native Web MIDI API (W3C standard), which provides access to MIDI hardware connected via USB. Audio synthesis on the client uses Tone.js, whose time scheduler independent of the V8 engine's *Garbage Collector* ensures the reproduction of notes with sub-millisecond temporal precision. Real-time communication is managed using Socket.io Client (v4).

The backend is a Node.js server with the Express.js framework deployed on Render.com (Linux container). The WebSocket server is implemented with Socket.io v4.8.3. Data persistence uses PostgreSQL Serverless (Neon.tech). Authentication employs JSON Web Tokens (JWT) under a stateless model. The storage of static assets (profile pictures, covers) is managed through Cloudinary. Server activity logs are produced using Winston.

### 3.2 Evaluated Module: Concert Room Module

The component evaluated in this study is exclusively the multiplayer rooms module, called Concert Room Module. This module allows up to four users to join a shared room and play piano simultaneously, with each player's notes being transmitted in real time to the rest.

**Flow of a musical event in Concert Room Module (WebSocket Protocol — Scenario B):**
The user presses a key on the physical piano connected via USB MIDI; the Web MIDI API triggers a *midimessage* event in the frontend; the VersusEngine.jsx component executes `socket.emit('play_note', { note, velocity, instrument })`; Socket.io encapsulates the message and transmits it through the persistent TCP tunnel to the server; the server executes `socket.to(roomId).emit('user_played_note', data)` to all participants in the room; the receiving client reproduces the note using Tone.js.

**Hypothetical flow using HTTP REST (Scenario A — Control Protocol):**
For each note, the frontend executes `axios.post('/api/test/note', data)`; the client establishes a new TCP connection (3-way handshake), sends HTTP headers and the JSON body; the server responds; the connection is closed or reused. This process is fully repeated for each MIDI event.

### 3.3 Characteristic System Load

The maximum capacity of the Concert Room Module is four players per room. The estimated frequency of MIDI events in real use ranges between 10 and 25 events per second per player (single notes and chords, respectively). The maximum expected load in a full room is 4 players × 25 events/s = **100 events/s**, a figure that served as the basis for designing the experiment's load.

---

## 4 Methodology

### 4.1 Study Design

A controlled experiment was designed with two comparable scenarios executed on the same system under equal network conditions:

- **Scenario A (control protocol):** HTTP REST via POST requests to the `/api/test/note` endpoint.
- **Scenario B (proposed protocol):** WebSocket via the `test_latencia_ws` event managed by Socket.io.

**Hypotheses:**
- H₀ (null): There is no statistically significant difference between the mean latency of HTTP REST and WebSocket under the emulated adverse network conditions.
- H₁ (alternative): WebSocket presents a mean latency that is statistically different from HTTP REST under the emulated adverse network conditions.

### 4.2 Experiment Variables

- **Independent variable:** Communication protocol (HTTP REST vs. WebSocket/Socket.io).
- **Dependent variables:** Mean latency (RTT in ms), maximum latency (*jitter*), latency variance, server CPU consumption, server RAM consumption.
- **Controlled variables:** Payload size (same JSON object in both protocols), sending frequency (25 events/s per client), number of concurrent clients (4), emulated network conditions (50 ms lag + 1% packet loss), server and client hardware, Node.js and Socket.io versions.

### 4.3 Environment Configuration

**Table 1.** Experiment environment configuration.

| Parameter | Value |
|---|---|
| Server (Node A) | Intel Core i7-8750H, 24 GB DDR4 RAM, POP! OS Linux |
| Client (Node B) | AMD Ryzen 5 5600G, 16 GB DDR4 3200 MHz RAM, Windows 11 |
| Network | WiFi 802.11ac LAN (same private subnet) |
| Network Emulation | Clumsy 0.3 — Lag 50 ms + Drop 1% |
| Protocol A (control) | HTTP REST — POST /api/test/note |
| Protocol B (proposed) | WebSocket — test_latencia_ws event |
| Concurrent Clients | 4 |
| Iterations per client | 1,000 |
| Warm-up phase | 100 discarded iterations per client |
| Analyzed samples (N) | 3,600 per protocol |
| Total load frequency | 100 events/s (25 per client) |

### 4.4 Adverse Network Emulation

Although PianoFlows is designed to operate over domestic WiFi/LAN networks, the conditions of these networks are inherently unpredictable: electromagnetic interference, router saturation, TCP retransmissions, and sporadic packet loss. The injection of an additional 50 ms delay and a 1% packet loss using Clumsy does not aim to simulate a specific network technology, but to establish a controlled and reproducible worst-case scenario that exposes the differences in resilience between protocols under conditions that would remain hidden in an ideal LAN. This methodology is analogous to the use of `tc netem` in Linux systems and is standard in network performance research [6].

Clumsy intercepts packets at the network driver level applying the filter `tcp.DstPort == 3000 or tcp.SrcPort == 3000`, affecting exclusively the traffic to and from the Node.js server.

### 4.5 Execution Procedure

The RTT measurement was performed by recording timestamps on the client. For HTTP REST, the client records `Date.now()` immediately before invoking the POST request and calculates the difference upon receiving the response (Algorithm 2). For WebSocket, the start timestamp is embedded within the payload of the emitted event, and the client calculates the RTT upon receiving the echo from the server (Algorithm 3). The server attaches hardware metrics (CPU load average, RAM heap) in each response, both in HTTP and WebSocket (Algorithm 1).

**Algorithm 1.** Handler for the WebSocket latency measurement event (Node.js/Socket.io).

```
socket.on('test_latencia_ws', (data) => {
    socket.emit('test_latencia_ws_response', {
        ...data,
        serverTime : Date.now(),
        cpuLoad    : os.loadavg()[0],
        ramMB      : (process.memoryUsage().heapUsed
                      / 1024 / 1024).toFixed(2)
    });
});
```

**Algorithm 2.** RTT measurement for HTTP REST in the client (Node.js/axios).

```
const start = Date.now();
const response = await axios.post(
    `${SERVER_URL}/api/test/note`, { midi: 60 });
const rtt = Date.now() - start;
fs.appendFileSync(CSV_HTTP,
    `${fase},${clientId},${iter},${rtt},
     ${response.data.cpuLoad},${response.data.ramMB},OK\n`);
```

**Algorithm 3.** RTT measurement for WebSocket in the client (Socket.io-client).

```
socket.emit('test_latencia_ws',
    { _testStart: Date.now(), _testIter: enviosIniciados });

socket.on('test_latencia_ws_response', (data) => {
    const rtt = Date.now() - data._testStart;
    fs.appendFileSync(CSV_WS,
        `${fase},${clientId},${iter},${rtt},
         ${data.cpuLoad},${data.ramMB},OK\n`);
});
```

### 4.6 Warm-up Phase

The Node.js V8 engine uses JIT (Just-In-Time) compilation, which implies that the first executions of a function are interpreted and are slower than subsequent ones, which are compiled into native code. To ensure that the analyzed data correspond to steady-state performance, the first 100 iterations (10% of N = 1,000) of each client, labeled as the WARMUP phase, were discarded. Only iterations labeled as the STEADY phase were included in the statistical analysis.

### 4.7 Result Logging and Analysis

The results of each iteration were stored in real time in independent CSV files per protocol (`resultados_latencia_http.csv` and `resultados_latencia_ws.csv`), containing the fields: phase, client ID, iteration number, latency in ms, CPU load average, and RAM heap in MB. For the statistical analysis, Welch's T-Test [13]—a variant of Student's T-Test for samples with unequal variances—was applied, since the observed variances differed between protocols (s²_HTTP = 3,590.65 versus s²_WS = 3,975.87). The degrees of freedom were calculated using the Welch-Satterthwaite equation [14], obtaining df = 7,179. A significance level α = 0.05 was adopted [Field, 2018].

---

## 5 Results

### 5.1 Descriptive Statistics

**Table 2.** Descriptive statistics of latency (RTT) by protocol — STEADY Phase (N = 3,600).

| Statistic | HTTP REST | WebSocket (Socket.io) |
|---|---:|---:|
| Mean (x̄) | 142.13 ms | 176.35 ms |
| Standard Deviation (s) | 59.92 ms | 63.05 ms |
| Variance (s²) | 3,590.65 | 3,975.87 |
| Minimum | 104 ms | 104 ms |
| Q1 (25th Percentile) | 123 ms | 140 ms |
| Median (P50) | 129 ms | 164 ms |
| Q3 (75th Percentile) | 143 ms | 169 ms |
| P90 | 165 ms | 248 ms |
| P99 | 473 ms | 450 ms |
| **Maximum (Lag Spike)** | **1,318 ms** | **580 ms** |
| IQR | 20 ms | 29 ms |
| Outliers | 105 (2.92%) | 433 (12.03%) |

**[PLACEHOLDER: Fig. 2]**
*Insert temporal line chart (latency per iteration, HTTP in red and WebSocket in blue, both in the same chart, Y-axis up to 1,400 ms, dotted line at 50 ms labeled "Critical threshold [7]"). Generate from the CSV files. Title: "Fig. 2. Temporal evolution of latency per iteration for HTTP REST and WebSocket under emulated adverse network conditions (50 ms lag + 1% packet loss)."*

Fig. 2 shows the temporal evolution of latency for both protocols. HTTP REST presents peaks of up to 1,318 ms sporadically, while WebSocket maintains a more stable profile with maximum peaks of 580 ms.

**[PLACEHOLDER: Fig. 3]**
*Insert comparative Box Plot with both protocols side by side. Exact values in FUENTE_7. Y-axis up to 1,400 ms. Title: "Fig. 3. Comparative Box Plot of latency distribution. The upper outliers of HTTP REST reach 1,318 ms compared to 580 ms for WebSocket."*

The Box Plot in Fig. 3 evidences that, although the median of HTTP REST (129 ms) is lower than that of WebSocket (164 ms), the upper tail of the HTTP REST distribution is significantly more extreme. HTTP REST presents 105 outliers (2.92%) reaching 1,318 ms, while WebSocket registers 433 outliers (12.03%) but bounded to a maximum of 580 ms.

**[PLACEHOLDER: Fig. 4]**
*Insert double frequency histogram (grouped bars per latency bin). Exact data in FUENTE_7. Title: "Fig. 4. Frequency histogram of latency by protocol. HTTP REST concentrates 83.92% of its requests under 150 ms but presents a right tail reaching 1,318 ms."*

The histogram in Fig. 4 reveals the asymmetric distribution of both protocols. 83.92% of HTTP REST requests were completed in less than 150 ms, which explains its lower mean. However, the remaining 2.30% generated latency peaks exceeding 400 ms, including a value of 1,318 ms, characteristic of the protocol's instability in the face of packet loss.

**[PLACEHOLDER: Fig. 5]**
*Insert CDF (Cumulative Distribution Function) curve. X-axis: latency in ms (100 to 1,400). Y-axis: cumulative probability (0% to 100%). Two curves: HTTP REST (red) and WebSocket (blue). Exact percentile data in FUENTE_7. Title: "Fig. 5. Cumulative Distribution Function (CDF) of latencies. Up to the 95th percentile, HTTP REST exhibits lower latency; however, in the tail of the distribution (P99.9 and P100), WebSocket demonstrates superior resilience."*

The CDF curve in Fig. 5 is particularly revealing: up to the 95th percentile, HTTP REST shows lower latency than WebSocket (169 ms versus 332 ms at P95). However, starting at the 99th percentile, the situation reverses: at P99.9, HTTP REST accumulates latencies up to 726 ms compared to 532 ms for WebSocket; and at the absolute maximum value, the difference reaches 738 ms. This phenomenon demonstrates that the superiority of HTTP REST under normal conditions completely disappears in the event of packet loss, precisely the most critical cases for musical synchronization.

**[PLACEHOLDER: Fig. 6]**
*Insert grouped bar chart comparing key metrics by percentile (Mean, Median, P90, P99, Maximum). Exact data in FUENTE_7. Title: "Fig. 6. Latency percentile comparison between HTTP REST and WebSocket. The most significant difference is observed in the maximum value, where HTTP exceeds WebSocket's peaks by 126.9%."*

### 5.2 Server Resource Consumption

**Table 3.** Node.js server resource consumption during the experiment.

| Metric | HTTP REST | WebSocket (Socket.io) |
|---|---:|---:|
| CPU Load Avg (1 min) | 1.607 | 1.612 |
| RAM Heap (MB) | 21.76 MB | 22.29 MB |

Server resource consumption was practically identical in both protocols (CPU difference of 0.31% and RAM of 2.44%), confirming that the bottleneck observed in latency was exclusively protocolar in nature and not due to the server's computing capacity.

### 5.3 Statistical Significance Test

**Table 4.** Welch's T-Test results.

| Parameter | Value |
|---|---:|
| Mean Difference (x̄_WS − x̄_HTTP) | 34.21 ms |
| Standard Error (SE) | 1.4498 |
| T-Statistic | 23.5997 |
| Degrees of Freedom (df) | 7,179 |
| p-value | < 0.0001 |
| Significance Level (α) | 0.05 |
| Decision | H₀ is rejected |

With T = 23.5997 and p < 0.0001, the observed difference between protocols is not the product of random network variations. H₀ is rejected and H₁ is accepted: WebSocket presents a mean latency statistically different from that of HTTP REST under the emulated adverse network conditions.

### 5.4 Negative Results and Execution Limitations

During the execution of the WebSocket experiment, the client script did not complete all the planned 4,000 iterations. In the instants when Clumsy dropped TCP packets, the ordered and reliable delivery mechanism of the TCP protocol blocked the execution thread until the retransmission was completed or the timeout expired, resulting in the manual interruption of the process using Ctrl+C. The analyzed valid samples were 3,600 per protocol (90% of the target sample), a statistically sufficient figure for the presented conclusions and consistent with the expected behavior of TCP Head-of-Line Blocking.

**[PLACEHOLDER: Fig. 7]**
*Insert screenshot of the Linux server terminal showing Winston logs during the execution of the experiment (HTTP POST requests and WebSocket connections). Title: "Fig. 7. Log of Node.js server activity during the experiment, showing the reception of HTTP requests and the establishment of four concurrent WebSocket connections."*

**[PLACEHOLDER: Fig. 8]**
*Insert screenshot of the Windows console executing the concurrent test script. Title: "Fig. 8. Client node console (Windows 11) executing the test script with four simultaneous clients."*

---

## 6 Discussion

### 6.1 Interpretation of the Mean-Maximum Paradox

The most counterintuitive result of this study is that HTTP REST has a lower mean latency (142.13 ms) than WebSocket (176.35 ms), yet it is the protocol with the most adverse behavior for musical synchronization. This apparent paradox is explained by the nature of the TCP Head-of-Line Blocking phenomenon [4].

WebSocket operates over a single persistent TCP tunnel. When Clumsy drops a packet, TCP stops the delivery of all pending MIDI messages in the queue until the lost packet is retransmitted and received. This blocking elevates the latency of all messages affected by the retransmission, increasing the mean. However, since the queue of pending messages continues to be processed once the retransmission is resolved, the peaks are bounded to the time of one TCP retransmission cycle (580 ms maximum in this experiment).

HTTP REST, in contrast, utilizes a pool of independent TCP connections (keep-alive). The loss of a packet only blocks the affected connection; the others continue, which keeps the mean latency lower. However, when a complete HTTP request is lost, the client must repeat the entire process of establishing the TCP connection and sending HTTP headers before being able to retransmit the MIDI event, generating latency peaks of up to 1,318 ms. These peaks are 2.27 times greater than WebSocket's maximums.

### 6.2 Relevance of Jitter for Musical Applications

For musical synchronization, the critical metric is not mean latency but maximum latency (*jitter*). A system that serves 97.08% of its requests in under 173 ms but in the remaining 2.92% generates 1,318 ms peaks is unacceptable for a rhythm game: the user will experience complete auditory desynchronization in those instances, destroying musical coherence regardless of how low the rest of the latencies are. Claypool and Finkel [7] demonstrated that perceptual degradation in interactive games occurs above 50 ms; in music, a peak of 1,318 ms equates to a note arriving more than a second late, making synchronized performance impossible.

WebSocket, despite its higher mean latency, guarantees that no request will exceed 580 ms under the evaluated conditions, providing a bounded and predictable behavior, a necessary condition for any real-time music engine.

### 6.3 Relationship with Previous Work

The results of Pimentel and Nickerson [5] indicated that WebSocket is consistently superior to HTTP in real-time applications. This study qualifies that finding: under perfect network conditions, the difference might be smaller; it is the introduction of packet loss that reveals WebSocket's superiority in the metric that truly matters for music. Cloud gaming studies [7][8][9] support the 50 ms threshold adopted in this work as a practical limit for perceptual synchronization. Soares et al. [11] confirm that *jitter* is the primary predictor of QoE degradation in interactive real-time applications, validating the relevance of the selected metric.

### 6.4 Threats to Validity

**Internal validity:** The experiment was executed in a controlled LAN network. The adverse conditions were emulated reproducibly using Clumsy, guaranteeing the consistency of results between executions. However, the use of Socket.io as an implementation of WebSocket introduces a layer of abstraction over the native WebSocket protocol, with room management, heartbeat, and automatic reconnection adding overhead not attributable to the standard protocol.

**External validity:** The results are directly applicable to systems with similar architectures (Node.js + Socket.io under high-frequency event loads). Generalization to other server environments, other WebSocket implementations, or workloads of a different nature requires further evaluation.

**Construct validity:** RTT measurement using `Date.now()` in JavaScript has a precision of 1 ms and can be affected by the Node.js event loop on the client. This limitation is inherent to the chosen execution environment and is shared by both protocols, so it does not affect the comparative validity of the results.

---

## 7 Conclusions and Future Work

This work empirically evaluated the impact of the communication protocol on latency and *jitter* in the real-time transmission of MIDI events in the PianoFlows web music engine. The experiments were executed under a controlled worst-case scenario (50 ms lag + 1% emulated packet loss), with four concurrent clients and 3,600 steady-state samples per protocol.

The main finding is that WebSocket reduced the maximum latency peaks (*jitter*) by 56% compared to HTTP REST (580 ms versus 1,318 ms), with a statistically significant difference (T = 23.5997; df = 7,179; p < 0.0001), rejecting the null hypothesis H₀. The mean latency of HTTP REST (142.13 ms) was lower than that of WebSocket (176.35 ms), but this advantage is irrelevant for musical synchronization: it is the peaks, not the means, that determine the quality of experience in rhythm applications.

The contribution of this study is the empirical demonstration that, under realistic adverse network conditions, maximum latency—and not the mean—is the correct metric for evaluating network protocols in distributed music engines, and that WebSocket's connection persistence is the only mechanism that allows bounding that maximum latency to tolerable levels.

The conditions under which this result was obtained are: mid-range hardware, WiFi/LAN network in a private subnet, 1% packet loss emulation, and a load of 100 MIDI events per second with 4 concurrent clients.

The main limitation of the WebSocket protocol identified in this study is TCP Head-of-Line Blocking: the loss of a packet blocks all pending messages in the tunnel, raising the mean latency compared to HTTP. This limitation is structural to the underlying TCP protocol.

As future work, it is proposed to evaluate WebTransport over QUIC/HTTP3 [12] as the successor protocol to WebSocket for distributed music engines. By operating over UDP instead of TCP, QUIC eliminates TCP Head-of-Line Blocking natively, which could result in a protocol with the low mean latency of HTTP REST and the bounded peaks of WebSocket, constituting the optimal solution for real-time music applications.

---

## References

1. Fette, I.; Melnikov, A.: The WebSocket Protocol. RFC 6455, Internet Engineering Task Force (IETF) (2011). https://www.rfc-editor.org/rfc/rfc6455
2. Loreto, S.; Saint-Andre, P.; Salsano, S.; Wilkins, G.: Known Issues and Best Practices for the Use of Long Polling and Streaming in Bidirectional HTTP. RFC 6202, IETF (2011). https://www.rfc-editor.org/rfc/rfc6202
3. Fielding, R.T.: Architectural Styles and the Design of Network-Based Software Architectures. Doctoral thesis, University of California, Irvine (2000). https://ics.uci.edu/~fielding/pubs/dissertation/top.htm
4. Grigorik, I.: *High Performance Browser Networking*. O'Reilly Media, Sebastopol, CA (2013). https://hpbn.co/
5. Pimentel, V.; Nickerson, B.G.: Communicating and Displaying Real-Time Data with WebSocket. *IEEE Internet Computing*, Vol. 16, No. 4, pp. 45–53 (2012). DOI: 10.1109/MIC.2012.64
6. Bozakov, Z.; Susitaival, P.: Performance Evaluation of WebSocket Protocol for Implementation of Real-Time Web Applications. In: *19th EUNICE/IFIP WG 6.6 International Workshop*, pp. 58–69. Springer, Berlin, Heidelberg (2013). DOI: 10.1007/978-3-642-40552-5_6
7. Claypool, M.; Finkel, D.: The Effects of Latency on Player Performance in Cloud-Based Games. In: *11th IEEE Consumer Communications and Networking Conference (CCNC)*, pp. 641–646. IEEE (2014). DOI: 10.1109/CCNC.2014.6940491
8. Huang, C.; Chen, A.; Chen, M.; Bhattacharyya, S.: GamingAnywhere: An Open Cloud Gaming System. In: *Proceedings of the 4th ACM Multimedia Systems Conference (MMSys '13)*, pp. 36–47. ACM (2013). DOI: 10.1145/2483977.2483981
9. Wang, F.; Liu, J.; Shou, M.: Network Quality for Cloud Gaming: Measurement and Analysis. In: *IEEE INFOCOM 2012*, pp. 2740–2744. IEEE (2012). DOI: 10.1109/INFOCOM.2012.6195696
10. Murley, P.; Ma, Z.; Mason, J.; Bailey, M.; Kuchhal, A.: WebSocket Adoption and the Landscape of the Real-Time Web. In: *Proceedings of the Web Conference 2021 (WWW '21)*, pp. 1192–1204. ACM, New York (2021). DOI: 10.1145/3442381.3450063
11. Soares, D.; Carvalho, M.; Ramos, G.; Correira, N.: A Stacking Learning-Based QoE Model for Cloud Gaming. In: *IEEE/IFIP Network Operations and Management Symposium (NOMS 2023)*. IEEE (2023). DOI: 10.1109/NOMS56928.2023.10154434
12. Caballero, D., et al.: Empirical Analysis of the Impact of Packet Loss on WebTransport Using Socket.IO. DiVA Portal, Linköping University (2023). https://www.diva-portal.org
13. Welch, B.L.: The generalization of Student's problem when several different population variances are involved. *Biometrika*, Vol. 34, No. 1-2, pp. 28–35 (1947). DOI: 10.1093/biomet/34.1-2.28
14. Satterthwaite, F.E.: An Approximate Distribution of Estimates of Variance Components. *Biometrics Bulletin*, Vol. 2, No. 6, pp. 110–114 (1946). DOI: 10.2307/3002019

---

## FINAL CHECKLIST BEFORE TRANSFERRING TO WORD

- [ ] **[PLACEHOLDER]** Fill in authorship data (name, affiliation, email, ORCID)
- [ ] **[PLACEHOLDER]** Insert Fig. 1 — Architecture diagram (already available)
- [ ] **[PLACEHOLDER]** Generate and insert Fig. 2 — Temporal line chart
- [ ] **[PLACEHOLDER]** Generate and insert Fig. 3 — Comparative Box Plot
- [ ] **[PLACEHOLDER]** Generate and insert Fig. 4 — Frequency histogram
- [ ] **[PLACEHOLDER]** Generate and insert Fig. 5 — CDF curve
- [ ] **[PLACEHOLDER]** Generate and insert Fig. 6 — Grouped bar chart by percentile
- [ ] **[PLACEHOLDER]** Capture and insert Fig. 7 — Linux server screenshot
- [ ] **[PLACEHOLDER]** Capture and insert Fig. 8 — Windows console screenshot
- [ ] Verify that all figures and tables are cited in the text
- [ ] Verify readability of all figures in grayscale
- [ ] Verify that no table is inserted as an image
- [ ] Algorithms 1, 2, and 3 must be in Courier 9pt in Word
- [ ] Main text in Times 10pt, justified, no bold in normal paragraphs (use italics for emphasis)
- [ ] The abstract must have between 150 and 250 words (verify final count)
- [ ] The final PDF must NOT have page numbers
- [ ] Insert the public repository link in the body of the article (in Methodology, section 4.5, or at the end)
- [ ] Total length: 12 to 15 pages including figures, tables, and references
